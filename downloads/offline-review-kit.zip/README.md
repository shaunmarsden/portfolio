# Offline review kit

Selected existing source from independently developed fictional exercises, with
Codex assistance. Not a production system or independent human validation.
See SOURCE-MANIFEST.json for source version, exact hashes and file selection.
No raw model responses, review keys, saved databases, downloaded research corpus,
private planning notes, repository history or credentials are included.

Requirements: Python with SQLite, Git, macOS or Linux. Standard library only.
No pip install, model key, paid inference, web fetch or live adapter is needed.
The workflow test uses a short attributed public-domain NIST reference fixture.
The model runner is included as an unchanged dependency of the workflow's
Completion interface; do not invoke its live provider commands for this review.

From the extracted kit root, initialise a LOCAL source snapshot. The automation
experiment captures a Git revision, so these tests need a local Git commit.
The synthetic commit identity below is a local fixture, not a human assessor.
This new commit is not the original historical experiment revision.

```sh
git init
git add .
git -c core.hooksPath=/dev/null -c commit.gpgsign=false -c user.name="Local source snapshot" -c user.email="snapshot@example.invalid" commit -m "Local review kit snapshot"
LABS="$PWD/Personal AI Knowledge Base/03 - Consulting Practice"
(cd "$LABS/Reliable Automation Lab" && python3 -m unittest -v test_transfer.py test_recovery_edges.py)
(cd "$LABS/Evaluation Lab" && python3 -m unittest -v test_evaluate_v2.py)
(cd "$LABS/Service Request Workflow" && python3 -m unittest -v test_service_workflow.py)
```

The automation tests execute their frozen fictional comparison in fresh temporary
stores and test crash/recovery paths. These are new offline executions. Their
timings do not recreate original timings. The evaluator tests use synthetic
controls; they do NOT reproduce the 144 historical model responses or later guard
holdout. Workflow tests use scripted identities and mocked external effects.
No independent human review is supplied or implied. Do not run this on real data.

Historical aggregates are dated, reported observations on the portfolio. This
subset is deliberately narrower than all project tests (47 automation, 119 full
model lab and 29 workflow). See the site for the actually verified kit-test count.
There is no licence grant for third-party references beyond their original terms.
