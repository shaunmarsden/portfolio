"""Fictional local timesheet integration. Standard library; no network or secrets.

The adapter models a separate destination commit domain. Demo capabilities are
trusted-host fixtures, not secure login tokens. All finance values are fictional.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import re
import sqlite3


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(encoded(value).encode()).hexdigest()


class Refused(Exception):
    pass


class TemporaryFailure(Exception):
    pass


class Interrupted(Exception):
    pass


@dataclass(frozen=True)
class Identity:
    name: str
    generation: int
    expires: int
    permissions: frozenset
    teams: frozenset


def validate(row, registry):
    if not isinstance(row, dict) or set(row) != {'id', 'version', 'person', 'project', 'team', 'minutes'}:
        raise Refused('invalid_fields')
    for name in ('id', 'person', 'project', 'team'):
        if not isinstance(row[name], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', row[name]):
            raise Refused('invalid_identifier')
    if type(row['version']) is not int or row['version'] < 1:
        raise Refused('invalid_version')
    if type(row['minutes']) is not int or not 1 <= row['minutes'] <= 1440:
        raise Refused('invalid_minutes')
    if row['project'] not in registry or registry[row['project']]['team'] != row['team']:
        raise Refused('project_team_mismatch')
    return posting(row, registry)


def subject(row, index):
    """Stable bounded audit subject even when an untrusted ID is not bindable."""
    rid = row.get('id') if isinstance(row, dict) else None
    return rid if isinstance(rid, str) and re.fullmatch(r'[A-Za-z0-9_-]{1,64}', rid) else '@input:' + str(index)


def posting(row, registry):
    rule = registry[row['project']]
    # Rates in this experiment divide exactly into cents per minute.
    return {'id': row['id'], 'source_hash': digest(row), 'account': rule['account'],
            'team': row['team'], 'cents': row['minutes'] * rule['cents_per_hour'] // 60}


class Source:
    def __init__(self, rows):
        self.rows = deepcopy(rows)
        self.current = {r['id']: deepcopy(r) for r in rows if isinstance(r, dict) and isinstance(r.get('id'), str)}

    def snapshot(self):
        return deepcopy(self.rows)

    def get(self, rid):
        return deepcopy(self.current.get(rid))

    def change(self, rid):
        self.current[rid] = {**self.current[rid], 'version': 2, 'minutes': 360}


class Finance:
    """Injectable local boundary: enforce permissions and atomic key+content dedup.

    A basic caller may omit its key, intentionally demonstrating append semantics.
    The adapter does not know challenge expected answers or perform source checks.
    """
    def __init__(self, path, fault='clean', source=None):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('CREATE TABLE IF NOT EXISTS ledger(seq INTEGER PRIMARY KEY, ikey TEXT UNIQUE, payload TEXT NOT NULL)')
        self.db.commit()
        self.fault, self.source = fault, source
        self.generation, self.now = 1, 100
        self.fired = set()
        self.calls = []
        self.down = fault == 'destination_down'

    def identity(self, basic=False):
        return Identity('basic-admin' if basic else 'transfer-worker', self.generation,
                        99 if self.fault == 'credential_expiry' and 'recovered' not in self.fired else 200,
                        frozenset({'read', 'write', 'delete'} if basic else {'read', 'write'}),
                        frozenset({'RED', 'BLUE'}))

    def authorise(self, actor, operation, team=None):
        self.calls.append({'operation': operation, 'actor': actor.name})
        if (actor.generation != self.generation or actor.expires <= self.now
                or operation not in actor.permissions or (team and team not in actor.teams)):
            raise Refused('identity_expired_revoked_or_forbidden')

    def hook(self, point, rid):
        if rid != 'TS-B' or (point, rid) in self.fired:
            return
        relevant = {'source_change_before_post': 'before_post', 'source_change_after_post': 'after_post',
                    'credential_rotation': 'before_post', 'local_commit_failure': 'checkpoint'}
        if relevant.get(self.fault) != point:
            return
        self.fired.add((point, rid))
        if self.fault.startswith('source_change'):
            self.source.change(rid)
        elif self.fault == 'credential_rotation':
            self.generation += 1
        else:
            raise sqlite3.OperationalError('simulated local receipt commit failure')

    def append(self, actor, payload, key=None):
        self.authorise(actor, 'write', payload['team'])
        rid = payload['id']
        if self.down:
            raise TemporaryFailure('destination_unavailable')
        if rid == 'TS-B' and self.fault == 'timeout_before_commit' and 'timeout' not in self.fired:
            self.fired.add('timeout')
            raise TemporaryFailure('timeout_before_commit')
        text = encoded(payload)
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            old = self.db.execute('SELECT seq,payload FROM ledger WHERE ikey=?', (key,)).fetchone() if key else None
            if old and old['payload'] != text:
                raise Refused('idempotency_content_conflict')
            if old:
                seq = old['seq']
            else:
                seq = self.db.execute('INSERT INTO ledger(ikey,payload) VALUES(?,?)', (key, text)).lastrowid
        if rid == 'TS-B' and self.fault == 'timeout_after_commit' and 'timeout' not in self.fired:
            self.fired.add('timeout')
            raise TemporaryFailure('timeout_after_commit')
        return {'seq': seq, 'id': rid, 'hash': digest(payload)}

    def read(self, actor):
        self.authorise(actor, 'read')
        # Read permission is also team-scoped, not just writes.
        result = []
        for row in self.db.execute('SELECT * FROM ledger ORDER BY seq'):
            try:
                payload = json.loads(row['payload'])
                fields = {'id', 'source_hash', 'account', 'team', 'cents'}
                if (not isinstance(payload, dict) or set(payload) != fields
                        or any(not isinstance(payload[k], str) for k in fields - {'cents'})
                        or type(payload['cents']) is not int):
                    raise Refused('destination_record_invalid')
            except (ValueError, TypeError):
                raise Refused('destination_record_invalid') from None
            if payload['team'] in actor.teams:
                result.append(dict(seq=row['seq'], **payload))
        return result

    def delete(self, actor):
        self.authorise(actor, 'delete')
        with self.db:
            self.db.execute('DELETE FROM ledger')

    def close(self):
        self.db.close()


class Basic:
    def __init__(self, source, finance, actor, registry, **unused):
        self.source, self.finance, self.actor, self.registry = source, finance, actor, registry
        self.reported, self.actions = set(), []

    def run(self):
        for row in self.source.snapshot():
            self.finance.hook('before_post', row['id'])
            try:
                self.finance.append(self.actor, posting(row, self.registry))
            except (KeyError, TypeError, Refused, TemporaryFailure):
                self.reported.add(row['id'])
                raise
            self.finance.hook('after_post', row['id'])
            self.finance.hook('checkpoint', row['id'])
            if self.finance.fault == 'interrupted_run' and 'interruption' not in self.finance.fired:
                self.finance.fired.add('interruption')
                raise Interrupted('interrupted after first posting')


class ManualSimulation:
    """Idealised scripted checklist, not an observed human or measured human time."""
    def __init__(self, source, finance, actor, registry, manifest, **unused):
        self.source, self.finance, self.actor, self.registry, self.manifest = source, finance, actor, registry, manifest
        self.reported, self.actions = set(), []

    def run(self):
        seen = {}
        for index, row in enumerate(self.source.snapshot(), 1):
            rid = subject(row, index)
            self.actions.append('check')
            try:
                value = validate(row, self.registry)
                if rid not in self.manifest:
                    raise Refused('record_outside_manifest')
                if rid in seen and seen[rid] != digest(row):
                    raise Refused('source_content_conflict')
                seen[rid] = digest(row)
                self.finance.hook('before_post', rid)
                if digest(self.source.get(rid)) != digest(row):
                    raise Refused('source_changed')
                for attempt in range(3):
                    try:
                        existing = [r for r in self.finance.read(self.actor) if r['id'] == rid]
                        if existing:
                            if len(existing) != 1 or {k: existing[0][k] for k in value} != value:
                                raise Refused('content_conflict')
                        else:
                            self.actions.append('copy')
                            self.finance.append(self.actor, value)
                        break
                    except TemporaryFailure:
                        self.actions.append('retry')
                        if attempt == 2:
                            raise
                self.finance.hook('after_post', rid)
                self.finance.hook('checkpoint', rid)
                if self.finance.fault == 'interrupted_run' and 'interruption' not in self.finance.fired:
                    self.finance.fired.add('interruption')
                    raise Interrupted('interrupted after first posting')
            except (Refused, TemporaryFailure):
                self.reported.add(rid)
                self.actions.append('review')
        self.reconcile()

    def reconcile(self):
        self.actions.append('check')
        rows = self.finance.read(self.actor)
        for rid in self.manifest:
            found = [r for r in rows if r['id'] == rid]
            try:
                expected = validate(self.source.get(rid), self.registry)
                if len(found) != 1 or {k: found[0][k] for k in expected} != expected:
                    raise Refused('reconciliation_mismatch')
            except Refused:
                self.reported.add(rid)
        self.reported.update(r['id'] for r in rows if r['id'] not in self.manifest)


class Controlled:
    def __init__(self, source, finance, actor, registry, manifest, state, registry_hash):
        self.source, self.finance, self.actor = source, finance, actor
        self.registry, self.manifest, self.registry_hash = registry, manifest, registry_hash
        self.db = sqlite3.connect(state)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS intents(id TEXT PRIMARY KEY, source_hash TEXT, payload TEXT, status TEXT, receipt TEXT);
        CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY, id TEXT, event TEXT, detail TEXT);
        CREATE TABLE IF NOT EXISTS exceptions(id TEXT, code TEXT, disposition TEXT, reviewer TEXT, reason TEXT, UNIQUE(id,code));
        ''')
        self.actions = []

    @property
    def reported(self):
        return {r['id'] for r in self.db.execute('SELECT id FROM exceptions')}

    def event(self, rid, event, detail):
        self.db.execute('INSERT INTO events(id,event,detail) VALUES(?,?,?)', (rid, event, encoded(detail)))

    def exception(self, rid, code):
        with self.db:
            self.db.execute('''INSERT INTO exceptions(id,code,disposition) VALUES(?,?,?)
                ON CONFLICT(id,code) DO UPDATE SET disposition='open',reviewer=NULL,reason=NULL
                WHERE exceptions.disposition='recovered' ''', (rid, code, 'open'))
            self.event(rid, 'exception', {'code': code})

    def run(self):
        # No untrusted record may replace authority configuration or identity.
        try:
            if digest(self.registry) != self.registry_hash:
                raise Refused('mapping_configuration_changed')
            self.finance.authorise(self.actor, 'write')
        except Refused as error:
            for rid in self.manifest:
                self.exception(rid, str(error))
            return
        for index, row in enumerate(self.source.snapshot(), 1):
            rid = subject(row, index)
            try:
                value = validate(row, self.registry)
                if rid not in self.manifest:
                    raise Refused('record_outside_manifest')
                if self.db.execute("SELECT 1 FROM exceptions WHERE id=? AND disposition IN ('reject','escalate')", (rid,)).fetchone():
                    raise Refused('review_disposition_blocks_retry')
                source_hash = digest(row)
                with self.db:
                    previous = self.db.execute('SELECT * FROM intents WHERE id=?', (rid,)).fetchone()
                    if previous and previous['source_hash'] != source_hash:
                        raise Refused('source_content_conflict')
                    if previous and previous['payload'] != encoded(value):
                        raise Refused('intent_content_conflict')
                    if not previous:
                        self.db.execute('INSERT INTO intents VALUES(?,?,?,?,?)', (rid, source_hash, encoded(value), 'pending', None))
                        self.event(rid, 'intent', {'source_hash': source_hash})
                # Confirmed effects are read back, never silently re-posted or
                # rewritten to conceal corrupted destination/local evidence.
                if previous and previous['status'] == 'posted':
                    continue
                self.finance.hook('before_post', rid)
                if digest(self.source.get(rid)) != source_hash:
                    raise Refused('source_changed_before_post')
                for attempt in range(1, 4):
                    try:
                        receipt = self.finance.append(self.actor, value, key='timesheet:' + rid)
                        break
                    except TemporaryFailure as error:
                        with self.db:
                            self.event(rid, 'transient_failure', {'attempt': attempt, 'code': str(error)})
                        if attempt == 3:
                            raise
                self.finance.hook('after_post', rid)
                self.finance.hook('checkpoint', rid)
                with self.db:
                    self.db.execute('UPDATE intents SET status=?,receipt=? WHERE id=?', ('posted', encoded(receipt), rid))
                    self.event(rid, 'receipt', receipt)
                if self.finance.fault == 'interrupted_run' and 'interruption' not in self.finance.fired:
                    self.finance.fired.add('interruption')
                    raise Interrupted('interrupted after first posting')
            except (Refused, TemporaryFailure) as error:
                self.exception(rid, str(error))
                if str(error) == 'identity_expired_revoked_or_forbidden':
                    for missing in set(self.manifest) - self.reported:
                        self.exception(missing, 'batch_blocked_by_identity')
                    break
        self.reconcile()

    def reconcile(self):
        try:
            rows = self.finance.read(self.actor)
        except Refused as error:
            for rid in self.manifest:
                self.exception(rid, str(error))
            return
        for rid in self.manifest:
            found = [r for r in rows if r['id'] == rid]
            intent = self.db.execute('SELECT * FROM intents WHERE id=?', (rid,)).fetchone()
            if not intent or len(found) != 1:
                self.exception(rid, 'missing_or_duplicate_posting')
            elif {k: found[0][k] for k in json.loads(intent['payload'])} != json.loads(intent['payload']):
                self.exception(rid, 'ledger_content_mismatch')
            elif intent['status'] != 'posted' or intent['receipt'] != encoded({'seq': found[0]['seq'], 'id': rid, 'hash': digest(json.loads(intent['payload']))}):
                self.exception(rid, 'local_receipt_unconfirmed_or_mismatched')
            elif digest(self.source.get(rid)) != intent['source_hash']:
                self.exception(rid, 'source_changed_after_snapshot')
            else:
                # Keep historical failures but mark objectively resolved conditions.
                with self.db:
                    self.db.execute("UPDATE exceptions SET disposition='recovered' WHERE id=? AND disposition='open'", (rid,))
                    self.event(rid, 'reconciled', {'seq': found[0]['seq']})
        for row in rows:
            if row['id'] not in self.manifest:
                self.exception(row['id'], 'unexpected_destination_record')

    def review(self, rid, code, decision, *, actor, reason):
        if actor.name == self.actor.name or 'review' not in actor.permissions or actor.expires <= self.finance.now:
            raise Refused('independent_reviewer_role_required')
        if decision not in {'reject', 'escalate'} or not isinstance(reason, str) or not reason.strip():
            raise Refused('review_decision_required')
        with self.db:
            result = self.db.execute("UPDATE exceptions SET disposition=?,reviewer=?,reason=? WHERE id=? AND code=? AND disposition='open'",
                                     (decision, actor.name, reason, rid, code))
            if result.rowcount != 1:
                raise Refused('exception_not_open')
            self.event(rid, 'scripted_review', {'actor': actor.name, 'decision': decision, 'reason': reason})
        self.actions.append('review')

    def close(self):
        self.db.close()
