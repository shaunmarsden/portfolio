#!/usr/bin/env python3
"""Execute the pre-frozen fictional challenge. All effects are local SQLite writes."""
import argparse
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import statistics
import subprocess
import time

import transfer as t

HERE = Path(__file__).resolve().parent


def save(path, obj):
    with path.open('x') as stream:
        json.dump(obj, stream, indent=2, sort_keys=True)
        stream.write('\n')


def verify():
    for name, sha in json.loads((HERE / 'freeze.json').read_text())['sha256'].items():
        if hashlib.sha256((HERE / name).read_bytes()).hexdigest() != sha:
            raise ValueError('Frozen input or criteria changed: ' + name)
    return json.loads((HERE / 'challenge.json').read_text())


def output_root(path):
    root = path.resolve()
    repo = HERE.parents[2]
    if root == repo or repo in root.parents:
        raise ValueError('Generated evidence must be outside the checkout')
    root.mkdir(parents=True, exist_ok=False)
    return root


def ledger_rows(finance):
    # Evaluation oracle only: bypass identity scopes to inspect the entire fixture.
    return [dict(seq=r['seq'], **json.loads(r['payload'])) for r in finance.db.execute('SELECT * FROM ledger ORDER BY seq')]


def episode(folder, design, case, registry):
    folder.mkdir()
    source = t.Source(case['records'])
    finance = t.Finance(folder / 'finance.sqlite', case['fault'], source)
    actor = finance.identity(basic=design == 'basic')
    if case['fault'] == 'unauthorised_identity':
        actor = t.Identity(actor.name, actor.generation, actor.expires, frozenset({'read'}), actor.teams)
    mapping = deepcopy(registry)
    if case['fault'] == 'incorrect_mapping':
        mapping['POLAR']['account'] = 'F-WRONG'
    # The idealised manual operator consults the canonical reference, not the
    # automation's mutable config. Neither runtime receives expected_postings.
    klass = {'manual_simulated': t.ManualSimulation, 'basic': t.Basic, 'controlled': t.Controlled}[design]
    worker = klass(source, finance, actor, registry if design == 'manual_simulated' else mapping,
                   manifest=case['manifest'], state=folder / 'journal.sqlite', registry_hash=t.digest(registry))
    failures = []

    def execute():
        try:
            worker.run()
        except (t.Refused, t.TemporaryFailure, t.Interrupted, sqlite_error, KeyError, TypeError) as error:
            failures.append({'type': type(error).__name__, 'message': str(error)})
            if design != 'basic':
                try:
                    worker.reconcile()
                except t.Refused as reconciliation_error:
                    failures.append({'type': type(reconciliation_error).__name__, 'message': str(reconciliation_error)})

    start = time.perf_counter()
    execute()
    first_rows = ledger_rows(finance)
    if case['fault'] == 'repeated_execution':
        execute()
    if case['recoverable']:
        # An explicitly scripted operator restores infrastructure/reference config
        # and issues a new scoped fixture identity. No source values are guessed.
        worker.actions.append('recovery')
        finance.down = False
        finance.fired.add('recovered')
        finance.fault = 'clean'
        worker.actor = finance.identity(basic=design == 'basic')
        worker.registry = deepcopy(registry)
        execute()
    # Distinguish integration-origin mistakes from later adversarial file edits.
    expected = {r['id']: t.posting(r, registry) for r in case['expected_postings']}
    transfer_errors = sum({k:r[k] for k in ('id','source_hash','account','team','cents')} != expected.get(r['id']) for r in ledger_rows(finance))
    if case['fault'] in ('reconciliation_mismatch', 'extraneous_posting'):
        with finance.db:
            if case['fault'] == 'reconciliation_mismatch':
                row = next((r for r in finance.db.execute('SELECT seq,payload FROM ledger') if json.loads(r['payload'])['id']=='TS-B'),None)
                if row:
                    changed = json.loads(row['payload']); changed['cents'] += 1
                    finance.db.execute('UPDATE ledger SET payload=? WHERE seq=?', (t.encoded(changed), row['seq']))
            else:
                finance.db.execute('INSERT INTO ledger(ikey,payload) VALUES(?,?)', ('fixture-intruder', t.encoded({'id':'TS-X','source_hash':'fixture','account':'F100','team':'RED','cents':1})))
        if design != 'basic':
            worker.reconcile()
    unauthorised_success = 0
    if case['fault'] == 'unauthorised_operation':
        try:
            finance.delete(worker.actor)
            unauthorised_success = 1
        except t.Refused:
            pass
        if design != 'basic':
            worker.reconcile()
    if design == 'controlled':
        reviewer = t.Identity('scripted-reviewer', 1, 200, frozenset({'review'}), frozenset())
        open_rows = worker.db.execute("SELECT id,code FROM exceptions WHERE disposition='open'").fetchall()
        for row in open_rows:
            worker.review(row['id'], row['code'], 'escalate', actor=reviewer,
                          reason='Scripted exercise disposition: unresolved; no finance amendment authorised.')
    elif design == 'manual_simulated':
        worker.actions.extend('review' for _ in worker.reported)
    elapsed = time.perf_counter() - start
    rows = ledger_rows(finance)
    expected = {r['id']: t.posting(r, registry) for r in case['expected_postings']}
    copies = Counter(r['id'] for r in rows)
    correct = sum({k:r[k] for k in ('id','source_hash','account','team','cents')} == expected.get(r['id']) for r in rows)
    missing = set(expected) - set(copies)
    incorrect = len(rows) - correct
    reported = worker.reported
    mismatches = {r['id'] for r in rows if {k:r[k] for k in ('id','source_hash','account','team','cents')} != expected.get(r['id'])}
    if case['fault'] == 'source_change_after_post':
        mismatches.add('TS-B')  # legitimate snapshot, but a later source edit needs explicit review
    unresolved = []
    pending = 0
    if design == 'controlled':
        unresolved = [dict(r) for r in worker.db.execute("SELECT * FROM exceptions WHERE disposition!='recovered'")]
        pending = worker.db.execute("SELECT count(*) FROM intents WHERE status!='posted'").fetchone()[0]
    outcome = {'design':design,'case':case['id'],'fault':case['fault'],'expected_postings':len(expected),
               'correct_postings':correct,'incorrect_postings':incorrect,'unsafe_transfer_writes':transfer_errors,'missed_records':len(missing),
               'correct_unique_records':sum(copies[rid]==1 and any({k:r[k] for k in value}==value for r in rows if r['id']==rid) for rid,value in expected.items()),
               'silent_missed_records':len(missing - reported),'duplicate_postings':sum(max(0,n-1) for n in copies.values()),
               'unreported_mismatches':len(mismatches - reported), 'unauthorised_successes':unauthorised_success,
               'duration_ms':elapsed*1000,'scripted_operator_actions':dict(Counter(worker.actions)),
               'recoverable':case['recoverable'], 'recovery_success': (not missing and not incorrect and all(n==1 for n in copies.values()) and not pending) if case['recoverable'] else None,
               'first_pass_postings':len(first_rows), 'final_postings':len(rows),'pending_intents':pending,
               'unresolved_exceptions':unresolved,'reported_ids':sorted(reported),'caught_failures':failures,
               'destination_operations':dict(Counter(c['operation'] for c in finance.calls)),
               'manual_estimated_seconds':sum(45 if a=='copy' else 15 for a in worker.actions if a in {'copy','check','retry','review'}) if design=='manual_simulated' else None}
    save(folder / 'observed.json',outcome)
    finance.close()
    if design == 'controlled': worker.close()
    return outcome


# Alias keeps the boundary explicit without catching arbitrary programming defects.
from sqlite3 import OperationalError as sqlite_error


def complexity():
    tree = ast.parse((HERE / 'transfer.py').read_text())
    groups = {'shared': [], 'basic': [], 'manual_simulated': [], 'controlled': []}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            group = {'Basic':'basic','ManualSimulation':'manual_simulated','Controlled':'controlled'}.get(node.name,'shared')
            groups[group].append(node)
    lines = (HERE / 'transfer.py').read_text().splitlines()
    result = {group:{'nonblank_lines':sum(sum(bool(lines[i].strip()) for i in range(n.lineno-1,n.end_lineno)) for n in nodes),
                   'functions':sum(isinstance(n,ast.FunctionDef) for node in nodes for n in ast.walk(node)),
                   'branches':sum(isinstance(n,(ast.If,ast.For,ast.While,ast.ExceptHandler)) for node in nodes for n in ast.walk(node))}
            for group,nodes in groups.items()}
    harness = (HERE / 'experiment.py').read_text()
    harness_tree = ast.parse(harness)
    result['harness'] = {'nonblank_lines': sum(bool(line.strip()) for line in harness.splitlines()),
                         'functions': sum(isinstance(n, ast.FunctionDef) for n in ast.walk(harness_tree)),
                         'branches': sum(isinstance(n, (ast.If, ast.For, ast.While, ast.ExceptHandler)) for n in ast.walk(harness_tree))}
    return result


def publishable_summary(result):
    """Explicit allowlist: no row payloads, exception notes, database or path data."""
    fields = ('aggregates_one_24_case_pass', 'timing_repeats', 'episodes_executed',
              'complexity', 'controlled_gate_pass', 'human_validation',
              'manual_baseline', 'live_api_calls')
    return {name: result[name] for name in fields}


def run(root, repeats=3, summary_out=None):
    data = verify()
    rows = []
    for repeat in range(1,repeats+1):
        for design in ('manual_simulated','basic','controlled'):
            for case in data['scenarios']:
                row=episode(root/f'{design}-{case["id"]}-{repeat}',design,case,data['registry'])
                row['repeat']=repeat;rows.append(row)
    aggregate={}
    for design in ('manual_simulated','basic','controlled'):
        selected=[r for r in rows if r['design']==design and r['repeat']==1]
        timed=[r['duration_ms'] for r in rows if r['design']==design]
        aggregate[design]={k:sum(r[k] for r in selected) for k in ['expected_postings','correct_postings','correct_unique_records','incorrect_postings','unsafe_transfer_writes','missed_records','silent_missed_records','duplicate_postings','unreported_mismatches','unauthorised_successes','final_postings']}
        aggregate[design].update({'recoverable_cases':sum(r['recoverable'] for r in selected),
                                  'recovery_successes':sum(r['recovery_success'] is True for r in selected),
                                  'scripted_operator_actions':dict(sum((Counter(r['scripted_operator_actions']) for r in selected),Counter())),
                                  'mean_duration_ms':statistics.mean(timed),'median_duration_ms':statistics.median(timed),
                                  'manual_assumed_seconds':sum(r['manual_estimated_seconds'] for r in selected) if design=='manual_simulated' else None})
    c=aggregate['controlled']
    gate=not any(c[k] for k in ['unsafe_transfer_writes','silent_missed_records','duplicate_postings','unreported_mismatches','unauthorised_successes']) and c['recovery_successes']==c['recoverable_cases']
    gate &= all(e['disposition'] in ['reject','escalate'] and e['reviewer']=='scripted-reviewer' for r in rows if r['design']=='controlled' for e in r['unresolved_exceptions'])
    summary={'aggregates_one_24_case_pass':aggregate,'timing_repeats':repeats,'episodes_executed':len(rows),'complexity':complexity(),'controlled_gate_pass':gate,
             'human_validation':'NOT PERFORMED','manual_baseline':'SIMULATED CHECKLIST; effort assumed, not observed', 'live_api_calls':0,'rows':rows}
    save(root/'results.json',summary)
    safe_summary = publishable_summary(summary)
    if summary_out is not None:
        summary_path = summary_out.resolve()
        if HERE.parents[2] in summary_path.parents:
            raise ValueError('Published summary must be outside the checkout')
        save(summary_path, safe_summary)
    files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
    save(root/'manifest.json',{'python':platform.python_version(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=HERE,text=True).strip(),
          'source_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ['transfer.py','experiment.py','protocol.json','challenge.json','freeze.json']},
          'published_summary_sha256': hashlib.sha256(summary_path.read_bytes()).hexdigest() if summary_out is not None else None,
          'artefact_sha256':files})
    print(json.dumps(safe_summary,indent=2))
    return gate


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--repeats',type=int,default=3)
    parser.add_argument('--summary-out',type=Path,help='Optional aggregate-only JSON for the private GitHub Actions artifact')
    args=parser.parse_args()
    if not 1<=args.repeats<=10:parser.error('repeats must be 1..10')
    raise SystemExit(0 if run(output_root(args.out),args.repeats,args.summary_out) else 1)
