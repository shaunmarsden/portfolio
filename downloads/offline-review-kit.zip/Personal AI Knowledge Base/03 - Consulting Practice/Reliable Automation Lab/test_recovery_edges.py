"""Additional adversarial checks; fictional fixtures only, no network or human assessor."""
from copy import deepcopy
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import random
import signal
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import experiment as e
import transfer as t

DATA = e.verify()
REGISTRY = DATA['registry']
ROWS = DATA['scenarios'][0]['records']


class EdgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = t.Source(ROWS)
        self.finance = t.Finance(self.root/'finance.sqlite', source=self.source)
        self.worker = t.Controlled(self.source, self.finance, self.finance.identity(), deepcopy(REGISTRY),
                                   [r['id'] for r in ROWS], self.root/'journal.sqlite', t.digest(REGISTRY))

    def tearDown(self):
        self.worker.close(); self.finance.close(); self.temp.cleanup()

    def replace_first_payload(self, payload):
        with self.finance.db:
            self.finance.db.execute('UPDATE ledger SET payload=? WHERE seq=1', (t.encoded(payload),))

    def test_recovered_exception_reopens_when_same_mismatch_recurs(self):
        self.worker.run()
        original = t.posting(ROWS[0], REGISTRY)
        self.replace_first_payload({**original, 'cents':1})
        self.worker.reconcile()
        self.replace_first_payload(original)
        self.worker.reconcile()
        self.assertEqual(self.worker.db.execute("SELECT disposition FROM exceptions WHERE id='TS-A'").fetchone()[0], 'recovered')
        self.replace_first_payload({**original, 'cents':2})
        self.worker.reconcile()
        self.assertEqual(self.worker.db.execute("SELECT disposition FROM exceptions WHERE id='TS-A'").fetchone()[0], 'open')

    def test_replay_does_not_recreate_deleted_confirmed_finance_row(self):
        self.worker.run()
        with self.finance.db:self.finance.db.execute('DELETE FROM ledger WHERE seq=1')
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)), 2)
        self.assertIn('TS-A', self.worker.reported)

    def test_replay_does_not_hide_corrupted_local_receipt(self):
        self.worker.run()
        with self.worker.db:self.worker.db.execute("UPDATE intents SET receipt='{}' WHERE id='TS-A'")
        self.worker.run()
        self.assertEqual(self.worker.db.execute("SELECT receipt FROM intents WHERE id='TS-A'").fetchone()[0], '{}')
        self.assertIn('TS-A', self.worker.reported)

    def test_confirmed_replay_performs_no_destination_write_requests(self):
        self.worker.run()
        before = sum(c['operation']=='write' for c in self.finance.calls)
        self.worker.run()
        # One batch-level authority check, but no three append requests.
        self.assertEqual(sum(c['operation']=='write' for c in self.finance.calls)-before, 1)

    def test_malformed_identifier_does_not_abort_valid_peers(self):
        for bad_id in [[], {}, 17, None, '', 'x'*1000]:
            with self.subTest(bad_id=bad_id):
                self.source.rows = [{**ROWS[0], 'id':bad_id}] + deepcopy(ROWS)
                self.worker.run()
                self.assertEqual(len(e.ledger_rows(self.finance)),3)
                self.assertTrue(any(r.startswith('@input:') for r in self.worker.reported))

    def test_manual_checklist_refuses_record_outside_approved_manifest(self):
        foreign = {**ROWS[0], 'id':'TS-OUTSIDE'}
        self.source.rows.append(foreign); self.source.current[foreign['id']]=foreign
        manual = t.ManualSimulation(self.source,self.finance,self.finance.identity(),REGISTRY,[r['id'] for r in ROWS])
        manual.run()
        self.assertNotIn('TS-OUTSIDE',{r['id'] for r in e.ledger_rows(self.finance)})
        self.assertIn('TS-OUTSIDE',manual.reported)

    def test_non_json_destination_data_is_explicit_reconciliation_failure(self):
        self.worker.run()
        with self.finance.db:self.finance.db.execute("UPDATE ledger SET payload='not json' WHERE seq=1")
        self.worker.reconcile()
        self.assertEqual(self.worker.reported, {'TS-A','TS-B','TS-C'})
        codes={r[0] for r in self.worker.db.execute('SELECT code FROM exceptions')}
        self.assertIn('destination_record_invalid',codes)

    def test_invalid_destination_shape_is_explicit_failure(self):
        self.worker.run()
        self.replace_first_payload({'id':[], 'team':'RED', 'cents':1})
        self.worker.reconcile()
        self.assertEqual(self.worker.reported, {'TS-A','TS-B','TS-C'})

    def test_pending_intent_corruption_blocks_destination_effect(self):
        self.finance.down=True
        self.worker.run()
        with self.worker.db:self.worker.db.execute("UPDATE intents SET payload='{}' WHERE id='TS-A'")
        self.finance.down=False
        self.worker.run()
        self.assertNotIn('TS-A',{r['id'] for r in e.ledger_rows(self.finance)})
        self.assertIn('intent_content_conflict',{r[0] for r in self.worker.db.execute("SELECT code FROM exceptions WHERE id='TS-A'")})

    def test_artifact_export_excludes_raw_and_unrecognised_fields(self):
        allowed = ('aggregates_one_24_case_pass', 'timing_repeats', 'episodes_executed',
                   'complexity', 'controlled_gate_pass', 'human_validation',
                   'manual_baseline', 'live_api_calls')
        record = {name: {} for name in allowed}
        record.update({'rows':[{'person':'must-not-export'}], 'private_paths':['must-not-export'], 'future_field':'must-not-export'})
        safe=e.publishable_summary(record)
        self.assertEqual(set(safe),set(allowed))
        self.assertNotIn('must-not-export',json.dumps(safe))

    def test_demo_summary_omits_rows_and_matches_manifest_hash(self):
        with tempfile.TemporaryDirectory() as d, redirect_stdout(io.StringIO()):
            root=Path(d)
            self.assertTrue(e.run(root,repeats=1,summary_out=root/'aggregate.json'))
            summary=json.loads((root/'aggregate.json').read_text())
            manifest=json.loads((root/'manifest.json').read_text())
            self.assertNotIn('rows',summary)
            self.assertEqual(summary['episodes_executed'],72)
            self.assertEqual(manifest['published_summary_sha256'],hashlib.sha256((root/'aggregate.json').read_bytes()).hexdigest())
            self.assertEqual(manifest['artefact_sha256']['aggregate.json'],manifest['published_summary_sha256'])

    def test_terminal_disposition_stays_terminal_on_repeated_error(self):
        self.worker.exception('TS-A','example')
        reviewer=t.Identity('review-fixture',1,200,frozenset({'review'}),frozenset())
        self.worker.review('TS-A','example','reject',actor=reviewer,reason='Synthetic reject')
        self.worker.exception('TS-A','example')
        self.assertEqual(self.worker.db.execute('SELECT disposition FROM exceptions').fetchone()[0],'reject')


CRASH_SCRIPT = r'''
import json,os,signal,sys
from pathlib import Path
import transfer as t
root=Path(sys.argv[1]);point=sys.argv[2]
data=json.loads(Path('challenge.json').read_text());rows=data['scenarios'][0]['records'];registry=data['registry']
source=t.Source(rows);finance=t.Finance(root/'finance.sqlite',source=source)
worker=t.Controlled(source,finance,finance.identity(),registry,[r['id'] for r in rows],root/'journal.sqlite',t.digest(registry))
def die():os.kill(os.getpid(),signal.SIGKILL)
original_event=worker.event
original_hook=finance.hook
original_append=finance.append
def event(rid,name,detail):
 original_event(rid,name,detail)
 if rid=='TS-A' and point=='intent_uncommitted' and name=='intent':die()
 if rid=='TS-A' and point=='receipt_uncommitted' and name=='receipt':die()
def hook(name,rid):
 original_hook(name,rid)
 if rid=='TS-A' and point=='intent_committed' and name=='before_post':die()
 if rid=='TS-B' and point=='first_record_complete' and name=='before_post':die()
def append(*args,**kwargs):
 receipt=original_append(*args,**kwargs)
 if point=='destination_committed':die()
 return receipt
worker.event=event;finance.hook=hook;finance.append=append
worker.run()
raise RuntimeError('crash point was not reached')
'''


class CrashTests(unittest.TestCase):
    @unittest.skipUnless(hasattr(signal,'SIGKILL'),'Requires POSIX process kill')
    def test_process_death_and_fresh_connections_recover_once(self):
        for point in ['intent_uncommitted','intent_committed','destination_committed','receipt_uncommitted','first_record_complete']:
            with self.subTest(point=point), tempfile.TemporaryDirectory() as d:
                root=Path(d)
                child=subprocess.run([sys.executable,'-c',CRASH_SCRIPT,str(root),point],cwd=e.HERE,capture_output=True,text=True,timeout=15)
                self.assertEqual(child.returncode,-signal.SIGKILL, child.stderr)
                source=t.Source(ROWS);finance=t.Finance(root/'finance.sqlite',source=source)
                worker=t.Controlled(source,finance,finance.identity(),REGISTRY,[r['id'] for r in ROWS],root/'journal.sqlite',t.digest(REGISTRY))
                try:
                    worker.run();worker.run()
                    self.assertEqual(len(e.ledger_rows(finance)),3)
                    self.assertEqual(worker.reported,set())
                    self.assertTrue(all(r[0]=='posted' for r in worker.db.execute('SELECT status FROM intents')))
                finally:worker.close();finance.close()


def seeded_recovery_traces(count=200):
    rng=random.Random(8112026)
    results=[]
    for number in range(count):
        rows=deepcopy(ROWS)
        for row in rows:row['minutes']=rng.randint(1,1440)
        fault=rng.choice(['clean','timeout_before_commit','timeout_after_commit','destination_down','interrupted_run','local_commit_failure'])
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);source=t.Source(rows);finance=t.Finance(root/'finance.sqlite',fault,source)
            worker=t.Controlled(source,finance,finance.identity(),REGISTRY,[r['id'] for r in rows],root/'journal.sqlite',t.digest(REGISTRY))
            try:
                try:worker.run()
                except (t.Interrupted,sqlite3.OperationalError):worker.reconcile()
                finance.down=False;finance.fault='clean'
                worker.run();worker.run()
                posted=e.ledger_rows(finance)
                expected={r['id']:r['minutes']*REGISTRY[r['project']]['cents_per_hour']//60 for r in rows}
                if len(posted)!=3 or {r['id']:r['cents'] for r in posted}!=expected:
                    raise AssertionError(('incorrect posting',number,fault,posted))
                if any(r[0]=='open' for r in worker.db.execute('SELECT disposition FROM exceptions')):
                    raise AssertionError(('unresolved recoverable fault',number,fault))
                results.append({'trace':number,'fault':fault,'unique_postings':len(posted),'correct':True})
            finally:worker.close();finance.close()
    return results


class SeededTests(unittest.TestCase):
    def test_200_seeded_recovery_and_replay_traces(self):
        self.assertEqual(len(seeded_recovery_traces()),200)


if __name__=='__main__':unittest.main()
