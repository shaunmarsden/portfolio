"""Offline tests of actual SQLite effects, failure windows and authority controls."""
from copy import deepcopy
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import threading
import unittest
from unittest.mock import patch

import experiment as e
import transfer as t

DATA = e.verify()
REGISTRY = DATA['registry']
ROWS = DATA['scenarios'][0]['records']


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.source=t.Source(ROWS)
        self.finance=t.Finance(self.root/'finance.sqlite',source=self.source)
        self.worker=t.Controlled(self.source,self.finance,self.finance.identity(),deepcopy(REGISTRY),
                                 ['TS-A','TS-B','TS-C'],self.root/'state.sqlite',t.digest(REGISTRY))

    def tearDown(self):
        self.worker.close();self.finance.close();self.temp.cleanup()

    def test_valid_posting_and_durable_receipts(self):
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)
        self.assertEqual([r['cents'] for r in e.ledger_rows(self.finance)],[4800,10800,2400])
        rows=self.worker.db.execute('SELECT * FROM intents').fetchall()
        self.assertTrue(all(r['status']=='posted' and json.loads(r['receipt'])['id']==r['id'] for r in rows))
        self.assertEqual(self.worker.reported,set())

    def test_duplicates_and_repeated_run_are_idempotent(self):
        self.source.rows.append(deepcopy(ROWS[0]))
        self.worker.run();self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)

    def test_invalid_shapes_values_and_extra_operations_are_rejected(self):
        invalid=[None,[],{}, {**ROWS[0],'minutes':True}, {**ROWS[0],'minutes':0},
                 {**ROWS[0],'minutes':1441}, {**ROWS[0],'minutes':1.5},
                 {**ROWS[0],'version':True}, {**ROWS[0],'version':0},
                 {**ROWS[0],'team':'BLUE'}, {**ROWS[0],'project':'none'},
                 {**ROWS[0],'operation':'delete'}, {**ROWS[0],'id':"';DROP TABLE ledger;--"}]
        for row in invalid:
            with self.subTest(row=row):
                with self.assertRaises(t.Refused):t.validate(row,REGISTRY)

    def test_invalid_record_does_not_block_valid_peers(self):
        self.source.rows[1]['minutes']='bad'
        self.worker.run()
        self.assertEqual({r['id'] for r in e.ledger_rows(self.finance)},{'TS-A','TS-C'})
        self.assertIn('TS-B',self.worker.reported)

    def test_missing_manifest_record_is_explicit_exception(self):
        self.source.rows.pop(1);self.source.current.pop('TS-B')
        self.worker.run()
        self.assertIn('TS-B',self.worker.reported)

    def test_outside_manifest_is_not_posted(self):
        self.source.rows.append({**ROWS[0],'id':'UNEXPECTED'})
        self.source.current['UNEXPECTED']=self.source.rows[-1]
        self.worker.run()
        self.assertNotIn('UNEXPECTED',{r['id'] for r in e.ledger_rows(self.finance)})
        self.assertIn('UNEXPECTED',self.worker.reported)

    def test_wrong_mapping_pin_blocks_all_writes(self):
        self.worker.registry['POLAR']['account']='wrong'
        self.worker.run()
        self.assertEqual(e.ledger_rows(self.finance),[])
        self.assertEqual(len(self.worker.reported),3)

    def test_changed_duplicate_cannot_replace_original_intent(self):
        self.worker.run()
        changed={**ROWS[0],'version':2,'minutes':240}
        self.source.rows.append(changed);self.source.current['TS-A']=changed
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)
        self.assertEqual(e.ledger_rows(self.finance)[0]['cents'],4800)
        self.assertIn('TS-A',self.worker.reported)

    def test_timeouts_before_and_after_commit_recover_without_duplicate(self):
        for fault in ['timeout_before_commit','timeout_after_commit']:
            with self.subTest(fault=fault):
                self.finance.fault=fault;self.finance.fired.clear()
                self.worker.run()
                self.assertEqual(len(e.ledger_rows(self.finance)),3)
                self.assertEqual(self.worker.reported,set())

    def test_retry_budget_three_then_exception(self):
        self.finance.down=True
        self.worker.run()
        events=self.worker.db.execute("SELECT detail FROM events WHERE id='TS-A' AND event='transient_failure'").fetchall()
        self.assertEqual([json.loads(r['detail'])['attempt'] for r in events],[1,2,3])
        self.assertEqual(len(self.worker.reported),3)
        self.finance.down=False;self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)
        self.assertTrue(all(r[0]=='recovered' for r in self.worker.db.execute('SELECT disposition FROM exceptions')))

    def test_expired_identity_not_retried_for_writes(self):
        self.worker.actor=t.Identity('expired',1,99,frozenset({'write','read'}),frozenset({'RED','BLUE'}))
        self.worker.run()
        self.assertEqual(e.ledger_rows(self.finance),[])
        self.assertEqual(sum(c['operation']=='write' for c in self.finance.calls),1)

    def test_scopes_block_cross_team_post_and_delete(self):
        actor=t.Identity('red-only',1,200,frozenset({'write','read'}),frozenset({'RED'}))
        with self.assertRaises(t.Refused):self.finance.append(actor,t.validate(ROWS[1],REGISTRY),'x')
        with self.assertRaises(t.Refused):self.finance.delete(actor)
        self.assertEqual(e.ledger_rows(self.finance),[])

    def test_reader_cannot_write_and_reads_are_team_scoped(self):
        self.worker.run()
        actor=t.Identity('red-reader',1,200,frozenset({'read'}),frozenset({'RED'}))
        self.assertEqual({r['team'] for r in self.finance.read(actor)},{'RED'})
        with self.assertRaises(t.Refused):self.finance.append(actor,t.validate(ROWS[0],REGISTRY),'bad')

    def test_rotation_revokes_old_identity_and_new_identity_recovers(self):
        self.finance.fault='credential_rotation'
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),1)
        self.worker.actor=self.finance.identity()
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)

    def test_source_edit_before_post_is_held(self):
        self.finance.fault='source_change_before_post'
        self.worker.run()
        self.assertNotIn('TS-B',{r['id'] for r in e.ledger_rows(self.finance)})
        self.assertIn('TS-B',self.worker.reported)

    def test_source_edit_after_post_requires_review_not_second_post(self):
        self.finance.fault='source_change_after_post'
        self.worker.run();self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)
        self.assertIn('TS-B',self.worker.reported)
        self.assertEqual(next(r for r in e.ledger_rows(self.finance) if r['id']=='TS-B')['cents'],10800)

    def test_receipt_commit_failure_leaves_recoverable_durable_intent_after_restart(self):
        self.finance.fault='local_commit_failure'
        with self.assertRaises(sqlite3.OperationalError):self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),2)
        self.assertEqual(self.worker.db.execute("SELECT status FROM intents WHERE id='TS-B'").fetchone()[0],'pending')
        self.worker.close()
        self.worker=t.Controlled(self.source,self.finance,self.finance.identity(),REGISTRY,['TS-A','TS-B','TS-C'],self.root/'state.sqlite',t.digest(REGISTRY))
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)

    def test_real_local_write_error_rolls_back_receipt_transaction(self):
        self.worker.db.execute("CREATE TRIGGER fail_receipt BEFORE UPDATE ON intents BEGIN SELECT RAISE(ABORT, 'local failure'); END")
        self.worker.db.commit()
        with self.assertRaises(sqlite3.IntegrityError):self.worker.run()
        self.assertEqual(self.worker.db.execute('SELECT status FROM intents').fetchone()[0],'pending')
        self.worker.db.execute('DROP TRIGGER fail_receipt');self.worker.db.commit()
        self.worker.run()
        self.assertEqual(len(e.ledger_rows(self.finance)),3)

    def test_ledger_corruption_and_unexpected_posting_are_reported(self):
        self.worker.run()
        with self.finance.db:
            self.finance.db.execute("UPDATE ledger SET payload=? WHERE seq=1",(t.encoded({**t.posting(ROWS[0],REGISTRY),'cents':1}),))
            self.finance.db.execute('INSERT INTO ledger(payload) VALUES(?)',(t.encoded({**t.posting(ROWS[0],REGISTRY),'id':'FOREIGN'}),))
        self.worker.reconcile()
        self.assertTrue({'TS-A','FOREIGN'}<=self.worker.reported)

    def test_local_receipt_tampering_is_not_reported_as_recovered(self):
        self.worker.run()
        with self.worker.db:self.worker.db.execute("UPDATE intents SET receipt='{}' WHERE id='TS-A'")
        self.worker.reconcile()
        self.assertIn('TS-A',self.worker.reported)

    def test_scripted_reviewer_cannot_post_amendments_or_self_approve(self):
        self.worker.exception('TS-A','missing')
        with self.assertRaises(t.Refused):self.worker.review('TS-A','missing','escalate',actor=self.worker.actor,reason='x')
        reviewer=t.Identity('review-fixture',1,200,frozenset({'review'}),frozenset())
        with self.assertRaises(t.Refused):self.worker.review('TS-A','missing','approve',actor=reviewer,reason='x')
        self.worker.review('TS-A','missing','escalate',actor=reviewer,reason='Synthetic unresolved exception')
        self.assertEqual(self.worker.db.execute('SELECT disposition FROM exceptions').fetchone()[0],'escalate')
        with self.assertRaises(t.Refused):self.worker.review('TS-A','missing','reject',actor=reviewer,reason='x')
        self.assertEqual(e.ledger_rows(self.finance),[])

    def test_rejected_exception_cannot_be_posted_on_later_rerun(self):
        self.finance.down=True
        self.worker.run()
        reviewer=t.Identity('review-fixture',1,200,frozenset({'review'}),frozenset())
        self.worker.review('TS-A','destination_unavailable','reject',actor=reviewer,reason='Do not transfer this record')
        self.finance.down=False
        self.worker.run()
        self.assertNotIn('TS-A',{r['id'] for r in e.ledger_rows(self.finance)})
        self.assertEqual({r['id'] for r in e.ledger_rows(self.finance)},{'TS-B','TS-C'})

    def test_expired_reviewer_is_denied(self):
        self.worker.exception('TS-A','missing')
        reviewer=t.Identity('review-fixture',1,99,frozenset({'review'}),frozenset())
        with self.assertRaises(t.Refused):self.worker.review('TS-A','missing','escalate',actor=reviewer,reason='x')

    def test_destination_key_conflict_leaves_first_posting_intact(self):
        value=t.validate(ROWS[0],REGISTRY)
        self.finance.append(self.worker.actor,value,'key')
        with self.assertRaises(t.Refused):self.finance.append(self.worker.actor,{**value,'cents':1},'key')
        self.assertEqual(len(e.ledger_rows(self.finance)),1)
        self.assertEqual(e.ledger_rows(self.finance)[0]['cents'],4800)

    def test_concurrent_destination_retries_commit_one_posting(self):
        barrier=threading.Barrier(2);errors=[]
        def post():
            finance=t.Finance(self.root/'finance.sqlite')
            try:
                barrier.wait(timeout=5)
                finance.append(finance.identity(),t.validate(ROWS[0],REGISTRY),'same-key')
            except Exception as error:errors.append(str(error))
            finally:finance.close()
        threads=[threading.Thread(target=post) for _ in range(2)]
        for thread in threads:thread.start()
        for thread in threads:thread.join(timeout=10)
        self.assertFalse(errors)
        self.assertTrue(all(not thread.is_alive() for thread in threads))
        self.assertEqual(len(e.ledger_rows(self.finance)),1)

    def test_local_intent_is_durable_before_destination_call(self):
        def check(*args,**kwargs):
            self.assertEqual(self.worker.db.execute("SELECT status FROM intents WHERE id='TS-A'").fetchone()[0],'pending')
            raise t.Interrupted('stop before remote call')
        with patch.object(self.finance,'append',side_effect=check):
            with self.assertRaises(t.Interrupted):self.worker.run()
        self.assertEqual(e.ledger_rows(self.finance),[])


class ExperimentTests(unittest.TestCase):
    def test_frozen_files_and_hypotheses_exist(self):
        self.assertEqual(len(e.verify()['scenarios']),24)
        self.assertEqual(len(json.loads((e.HERE/'protocol.json').read_text())['hypotheses']),3)

    def test_frozen_input_tampering_is_refused(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name in ['freeze.json','protocol.json','challenge.json']:
                (root/name).write_bytes((e.HERE/name).read_bytes())
            (root/'challenge.json').write_text('{}')
            with patch.object(e,'HERE',root):
                with self.assertRaisesRegex(ValueError,'Frozen input'):
                    e.verify()

    def test_no_output_inside_checkout_and_no_overwrite(self):
        with self.assertRaises(ValueError):e.output_root(e.HERE/'outputs')
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(FileExistsError):e.output_root(Path(d))

    def test_basic_negative_control_demonstrates_duplicate_problem(self):
        with tempfile.TemporaryDirectory() as d:
            case=next(c for c in DATA['scenarios'] if c['fault']=='repeated_execution')
            result=e.episode(Path(d)/'case','basic',case,REGISTRY)
            self.assertEqual(result['duplicate_postings'],3)

    def test_manual_is_explicit_simulation_with_estimated_effort(self):
        with tempfile.TemporaryDirectory() as d:
            result=e.episode(Path(d)/'case','manual_simulated',DATA['scenarios'][0],REGISTRY)
            self.assertEqual(result['correct_unique_records'],3)
            self.assertEqual(result['manual_estimated_seconds'],195)

    def test_complete_frozen_challenge_meets_controlled_gate(self):
        with tempfile.TemporaryDirectory() as d, redirect_stdout(io.StringIO()):
            self.assertTrue(e.run(Path(d),repeats=1))
            result=json.loads((Path(d)/'results.json').read_text())
            controlled=result['aggregates_one_24_case_pass']['controlled']
            basic=result['aggregates_one_24_case_pass']['basic']
            self.assertEqual(result['episodes_executed'],72)
            self.assertEqual(controlled['recovery_successes'],6)
            self.assertEqual(controlled['unsafe_transfer_writes'],0)
            self.assertEqual(controlled['duplicate_postings'],0)
            self.assertEqual(controlled['silent_missed_records'],0)
            self.assertEqual(controlled['incorrect_postings'],2) # intentional file corruption, detected
            self.assertGreater(basic['duplicate_postings'],0)

    def test_no_network_on_all_runtime_alternatives(self):
        with patch('socket.socket',side_effect=AssertionError('Network forbidden')):
            for design in ['manual_simulated','basic','controlled']:
                with tempfile.TemporaryDirectory() as d:
                    result=e.episode(Path(d)/'case',design,DATA['scenarios'][0],REGISTRY)
                    self.assertEqual(result['correct_unique_records'],3)


if __name__=='__main__':unittest.main()
