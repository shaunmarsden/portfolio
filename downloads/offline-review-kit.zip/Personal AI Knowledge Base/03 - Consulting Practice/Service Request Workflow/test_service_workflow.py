"""Synthetic actor fixtures are not actual human approvals or assessments.
Reference fixture: short NIST public-domain excerpt from the registered overview.
"""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from service_workflow import Actor, Completion, Workflow
from public_research import passages

SOURCE = {'id': 'NIST-RMF', 'title': 'NIST AI RMF',
          'url': 'https://www.nist.gov/itl/ai-risk-management-framework'}
REFERENCE = ('The NIST AI Risk Management Framework (AI RMF) is intended for voluntary use and '
             'to improve the ability to incorporate trustworthiness considerations into the design, '
             'development, use, and evaluation of AI products, services, and systems.')
CORPUS = passages(REFERENCE, SOURCE)
REQUEST = dict(request_id='fictional-001', kind='research', priority='normal',
               description='Fictional Harbour Desk requests a public AI risk reference.',
               reference_question='How is trustworthiness incorporated into AI design and evaluation?')
USER = Actor('demo-requester', frozenset({'submit'}))
REVIEWER = Actor('demo-reviewer', frozenset({'review'}))
OPERATOR = Actor('demo-operator', frozenset({'execute'}))


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'workflow.sqlite')
        self.w = Workflow(self.path, CORPUS)
        self.addCleanup(self.temp.cleanup); self.addCleanup(self.w.close)

    def submit(self, **changes):
        return self.w.handle('submit', {**REQUEST, **changes}, USER)

    def decide(self, decision='approve', **changes):
        return self.w.handle('decide', {**dict(request_id=REQUEST['request_id'], decision_id='d1',
                             expected_version=0, decision=decision,
                             reason='Synthetic reviewer fixture checked cited reference.'), **changes}, REVIEWER)

    def execute(self):
        return self.w.handle('execute', {'request_id': REQUEST['request_id']}, OPERATOR)

    def state(self):
        return self.w.handle('get', {'request_id': REQUEST['request_id']}, USER)['result']

    def test_success_and_trace_without_network(self):
        with patch('socket.socket.connect', side_effect=AssertionError('Network forbidden')):
            result = self.submit(); self.assertTrue(result['ok'])
            self.assertEqual(result['result']['status'], 'awaiting_review')
            self.assertTrue(self.decide()['ok']); receipt = self.execute()['result']
        self.assertTrue(receipt['local_only'])
        state = self.state(); self.assertEqual(state['status'], 'completed')
        self.assertEqual([e['event'] for e in state['audit']],
                         ['recommendation_created', 'human_decision_recorded', 'action_completed'])
        self.assertEqual(state['audit'][0]['data']['evidence']['citations'][0]['url'], SOURCE['url'])
        self.assertEqual(state['audit'][1]['actor'], REVIEWER.id)
        self.assertEqual(state['audit'][2]['actor'], OPERATOR.id)

    def test_bad_requests_never_create_state(self):
        for changes in ({'kind': 'bad'}, {'priority': 'critical'}, {'request_id': '../bad'},
                        {'description': ''}, {'description': 'a'*2001}, {'reference_question': 42},
                        {'actor': REVIEWER.id}, {'extra': True}):
            with self.subTest(changes=changes): self.assertEqual(self.submit(**changes)['status'], 400)
        self.assertEqual(self.w.handle('submit', {}, USER)['status'], 400)
        self.assertEqual(self.w.handle('submit', {'x': float('nan')}, USER)['status'], 400)
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM requests').fetchone()[0], 0)

    def test_duplicate_and_conflicting_request(self):
        first = self.submit()['result']; self.assertEqual(self.submit()['result'], first)
        self.assertEqual(len(self.state()['audit']), 1)
        self.assertEqual(self.submit(description='Different')['error'], 'id_conflict')

    def test_permissions_and_self_approval(self):
        self.assertEqual(self.w.handle('submit', REQUEST, OPERATOR)['status'], 403)
        self.submit()
        self.assertEqual(self.w.handle('get', {'request_id': REQUEST['request_id']}, Actor('other', frozenset()))['status'], 403)
        self.assertEqual(self.w.handle('execute', {'request_id': REQUEST['request_id']}, USER)['status'], 403)
        own = Actor(USER.id, frozenset({'review'}))
        decision = dict(request_id=REQUEST['request_id'], decision_id='self', expected_version=0,
                        decision='approve', reason='Cannot approve own request')
        self.assertEqual(self.w.handle('decide', decision, OPERATOR)['status'], 403)
        self.assertEqual(self.w.handle('decide', decision, own)['error'], 'self_approval_denied')
        self.assertEqual(self.w.handle('metrics', {}, USER)['status'], 403)

    def test_cannot_execute_without_approval(self):
        self.submit(); self.assertEqual(self.execute()['error'], 'approval_required')
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM actions').fetchone()[0], 0)

    def test_rejection_is_terminal(self):
        self.submit(); self.assertTrue(self.decide('reject')['ok'])
        self.assertEqual(self.execute()['error'], 'approval_required')
        self.assertEqual(self.decide(decision_id='d2')['error'], 'stale_or_terminal_request')
        self.assertEqual(self.state()['status'], 'rejected')

    def test_human_edit_controls_final_action(self):
        self.submit(); self.assertTrue(self.decide(queue='access-review')['ok'])
        self.assertEqual(self.execute()['result']['queue'], 'access-review')
        self.assertEqual(self.state()['recommendation']['queue'], 'research-desk')
        self.assertEqual(self.state()['decision']['final_queue'], 'access-review')

    def test_bad_or_stale_decisions_preserve_pending_state(self):
        self.submit()
        for change in ({'expected_version': 1}, {'expected_version': True}, {'queue': 'grant-admin'},
                       {'queue': []}, {'decision': 'execute'}, {'reason': ''}):
            with self.subTest(change=change): self.assertFalse(self.decide(**change)['ok'])
        self.assertEqual(self.state()['status'], 'awaiting_review')

    def test_decision_and_execution_replays_are_idempotent(self):
        self.submit(); d = self.decide()['result']; self.assertEqual(self.decide()['result'], d)
        r = self.execute()['result']; self.assertEqual(self.execute()['result'], r)
        self.assertEqual(self.decide()['result'], d)
        self.assertEqual(self.decide(reason='Changed reason')['error'], 'decision_id_conflict')
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM actions').fetchone()[0], 1)
        self.assertEqual(sum(e['event']=='action_completed' for e in self.state()['audit']), 1)

    def test_missing_evidence_can_escalate_but_not_approve(self):
        self.submit(reference_question='What is the VAT rate on Mars?')
        self.assertEqual(self.decide()['error'], 'missing_evidence')
        self.assertTrue(self.decide('escalate')['ok'])
        self.assertEqual(self.execute()['error'], 'approval_required')

    def test_urgent_and_incident_rules_cannot_be_overridden(self):
        for i, change in enumerate(({'priority': 'urgent'}, {'kind': 'incident'})):
            rid = 'urgent-' + str(i); self.submit(request_id=rid, **change)
            self.assertEqual(self.decide(request_id=rid, decision_id='d'+rid, queue='research-desk')['error'], 'escalation_required')
            self.assertTrue(self.decide('escalate', request_id=rid, decision_id='e'+rid)['ok'])

    def test_access_request_only_assigns_review_queue(self):
        self.submit(kind='access'); self.decide(); r = self.execute()['result']
        self.assertEqual(r['queue'], 'access-review'); self.assertEqual(r['operation'], 'assign_queue')

    def test_failure_rollback_and_recovery_use_same_key_and_payload(self):
        self.submit(); self.decide(); calls = []
        def fail(key, payload):
            calls.append((key, payload)); raise RuntimeError('private-adapter-detail')
        self.w.action = fail; result = self.execute()
        self.assertEqual(result['error'], 'action_failed'); self.assertNotIn('private', json.dumps(result))
        self.assertEqual(self.state()['status'], 'failed')
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM actions').fetchone()[0], 0)
        def recover(key, payload):
            calls.append((key, payload)); return {'idempotency_key': key, 'mock_reference': 'fictional'}
        self.w.action = recover; self.assertTrue(self.execute()['ok'])
        self.assertEqual(calls[0], calls[1]); self.assertEqual(self.state()['status'], 'completed')
        self.assertIn('action_failed', [e['event'] for e in self.state()['audit']])

    def test_wrong_adapter_receipt_does_not_commit_success(self):
        self.submit(); self.decide(); self.w.action = lambda key, payload: {'idempotency_key': 'wrong'}
        self.assertEqual(self.execute()['error'], 'action_failed'); self.assertEqual(self.state()['status'], 'failed')

    def test_restart_preserves_receipt(self):
        self.submit(); self.decide(); receipt = self.execute()['result']; other = Workflow(self.path, CORPUS)
        try: self.assertEqual(other.handle('execute', {'request_id': REQUEST['request_id']}, OPERATOR)['result'], receipt)
        finally: other.close()

    def test_database_write_failure_rolls_back_action_then_recovers(self):
        self.submit(); self.decide()
        self.w.db.executescript("""CREATE TRIGGER fail_completion BEFORE UPDATE ON requests
          WHEN NEW.status='completed' BEGIN SELECT RAISE(ABORT,'injected failure'); END;""")
        self.assertEqual(self.execute()['error'], 'storage_unavailable')
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM actions').fetchone()[0], 0)
        self.assertEqual(self.state()['status'], 'failed')
        self.assertFalse(any(e['event']=='action_completed' for e in self.state()['audit']))
        self.w.db.execute('DROP TRIGGER fail_completion')
        self.assertTrue(self.execute()['ok'])

    def test_mock_external_side_effect_deduplicates_after_local_commit_failure(self):
        self.submit(); self.decide(); cache = {}; applied = []
        def adapter(key, payload):
            if key not in cache:
                applied.append(payload)
                cache[key] = {'idempotency_key': key, 'mock_reference': 'fictional-external-receipt'}
            return cache[key]
        self.w.action = adapter
        self.w.db.executescript("""CREATE TRIGGER fail_completion BEFORE UPDATE ON requests
          WHEN NEW.status='completed' BEGIN SELECT RAISE(ABORT,'injected failure'); END;""")
        self.assertEqual(self.execute()['error'], 'storage_unavailable')
        self.assertEqual(len(applied), 1)  # Mock side effect occurred, local receipt rolled back.
        self.w.db.execute('DROP TRIGGER fail_completion')
        self.assertTrue(self.execute()['ok'])
        self.assertEqual(len(applied), 1)  # Adapter, not SQLite, deduplicates external work.

    def test_concurrent_execution_commits_one_action(self):
        from concurrent.futures import ThreadPoolExecutor
        self.submit(); self.decide()
        def execute_in_separate_connection(_):
            other = Workflow(self.path, CORPUS)
            try: return other.handle('execute', {'request_id': REQUEST['request_id']}, OPERATOR)
            finally: other.close()
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(execute_in_separate_connection, range(2)))
        self.assertTrue(all(r['ok'] for r in results))
        self.assertEqual(results[0]['result'], results[1]['result'])
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM actions').fetchone()[0], 1)
        self.assertEqual(sum(e['event']=='action_completed' for e in self.state()['audit']), 1)

    def test_database_failure_reports_unavailable_monitoring(self):
        other = Workflow(':memory:', CORPUS); other.close(); r = other.handle('submit', REQUEST, USER)
        self.assertEqual(r['error'], 'storage_unavailable'); self.assertTrue(r['recoverable'])
        self.assertFalse(r['monitoring_persisted'])

    def test_advisor_disabled_even_when_injected(self):
        calls = []; other = Workflow(':memory:', CORPUS, advisor=lambda *a: calls.append(a))
        try:
            r = other.handle('submit', REQUEST, USER); self.assertTrue(r['ok']); self.assertFalse(calls)
            self.assertFalse(r['result']['recommendation']['ai']['enabled'])
        finally: other.close()

    def test_explicit_advisor_is_non_authoritative_and_records_usage(self):
        calls = []
        def advisor(request, evidence):
            calls.append(request['request_id'])
            return Completion('{"queue":"access-review","reason":"Synthetic test double."}',
                              'fixture-not-a-real-model', 23, 11, 'stop', 'fixture', .01, 1)
        other = Workflow(':memory:', CORPUS, advisor=advisor, enable_ai=True)
        try:
            r = other.handle('submit', REQUEST, USER)['result']; other.handle('submit', REQUEST, USER)
            self.assertEqual(len(calls), 1); self.assertEqual(r['status'], 'awaiting_review')
            self.assertEqual(r['recommendation']['queue'], 'research-desk')
            self.assertEqual(r['recommendation']['ai']['suggestion']['queue'], 'access-review')
            m = other.handle('metrics', {}, OPERATOR)['result']; self.assertEqual(m['reported_input_tokens'], 23)
            self.assertEqual(m['reported_output_tokens'], 11); self.assertIsNone(m['api_cost_usd'])
        finally: other.close()

    def test_advisor_cannot_replace_missing_evidence_even_on_failure(self):
        for raises in (False, True):
            def advisor(request, evidence):
                evidence['status'] = 'extractive'
                evidence['answer'] = 'Forged adapter evidence'
                evidence['citations'].append({'quote': 'Forged citation'})
                if raises:
                    raise RuntimeError('Synthetic adapter error')
                return Completion('{"queue":"research-desk","reason":"Fixture only"}', 'fixture', 0, 0, None, None, 0, 1)
            other = Workflow(':memory:', CORPUS, advisor=advisor, enable_ai=True)
            try:
                request = {**REQUEST, 'reference_question': 'What is the VAT rate on Mars?'}
                out = other.handle('submit', request, USER)['result']
                self.assertEqual(out['recommendation']['evidence']['status'], 'abstain')
                self.assertEqual(out['recommendation']['evidence']['citations'], [])
                decision = dict(request_id=REQUEST['request_id'], decision_id='probe', expected_version=0,
                                decision='approve', reason='Scripted gate regression fixture')
                self.assertEqual(other.handle('decide', decision, REVIEWER)['error'], 'missing_evidence')
                audit = other.handle('get', {'request_id': REQUEST['request_id']}, USER)['result']['audit']
                self.assertEqual(audit[0]['data']['evidence']['status'], 'abstain')
            finally:
                other.close()

    def test_advisor_cannot_mutate_nested_reference_citation(self):
        def advisor(request, evidence):
            evidence['citations'][0]['quote'] = 'Forged nested citation'
            evidence['citations'][0]['url'] = 'https://example.invalid/forged'
            return Completion('{"queue":"research-desk","reason":"Fixture only"}', 'fixture', 0, 0, None, None, 0, 1)
        other = Workflow(':memory:', CORPUS, advisor=advisor, enable_ai=True)
        try:
            out = other.handle('submit', REQUEST, USER)['result']['recommendation']['evidence']
            self.assertEqual(out['citations'][0]['quote'], CORPUS[0]['text'])
            self.assertEqual(out['citations'][0]['url'], SOURCE['url'])
            self.assertEqual(out['answer'], out['citations'][0]['quote'])
        finally:
            other.close()

    def test_deep_payload_returns_validation_error_at_host_boundary(self):
        nested = 0
        for _ in range(1200):
            nested = [nested]
        result = self.w.handle('submit', {'extra': nested}, USER)
        self.assertEqual(result['status'], 400)
        # CPython encoder recursion limits differ: either reject during encoding
        # or reject the successfully decoded but invalid request fields.
        self.assertIn(result['error'], ('invalid_payload', 'invalid_fields'))
        with patch('service_workflow.encoded', side_effect=RecursionError('Encoder fixture')):
            result = self.w.handle('submit', {}, USER)
        self.assertEqual(result['status'], 400)
        self.assertEqual(result['error'], 'invalid_payload')
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM requests').fetchone()[0], 0)

    def test_deep_json_command_returns_json_without_traceback(self):
        raw = '{"operation":"submit","payload":{"extra":' + '['*1200 + '0' + ']'*1200 + '}}'
        args = [sys.executable, str(Path(__file__).with_name('service_workflow.py')),
                '--db', self.path, '--actor', 'requester']
        result = subprocess.run(args, input=raw, text=True, capture_output=True)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stderr, '')
        self.assertEqual(json.loads(result.stdout)['status'], 400)

    def test_advisor_failure_and_malformed_output_are_sanitized(self):
        for response in (RuntimeError('secret-detail'), Completion('secret-bad-json', 'fixture', 1, 1, None, None, 0, 1),
                         Completion('{"queue":"grant-admin","reason":"bad"}', 'fixture', 1, 1, None, None, 0, 1)):
            def advisor(*a):
                if isinstance(response, Exception): raise response
                return response
            other = Workflow(':memory:', CORPUS, advisor=advisor, enable_ai=True)
            try:
                r = other.handle('submit', REQUEST, USER); self.assertTrue(r['ok'])
                self.assertEqual(r['result']['recommendation']['ai']['error'], 'advisor_failed')
                self.assertNotIn('secret', json.dumps(r))
            finally: other.close()

    def test_source_allowlist(self):
        for row in ({**CORPUS[0], 'url': 'https://example.invalid/private'}, {'source_id': 'UNKNOWN', 'url': None}):
            with self.subTest(row=row), self.assertRaises(ValueError): Workflow(':memory:', [row])

    def test_metrics_track_failures_latency_and_unmeasured_cost(self):
        self.submit(); self.execute(); m = self.w.handle('metrics', {}, OPERATOR)['result']
        self.assertEqual(m['operations'], 2); self.assertEqual(m['failures_by_code']['approval_required'], 1)
        self.assertGreaterEqual(m['elapsed_s_total'], 0); self.assertGreaterEqual(m['elapsed_s_max'], 0)
        self.assertEqual(m['advisor_invocations'], 0); self.assertEqual(m['api_cost_usd'], 0)
        self.assertIsNone(m['local_host_cost_usd'])

    def test_json_command_boundary(self):
        index = Path(self.temp.name)/'index.json'; index.write_text(json.dumps(CORPUS))
        args = [sys.executable, str(Path(__file__).with_name('service_workflow.py')), '--db', self.path,
                '--actor', 'requester', '--index', str(index)]
        p = subprocess.run(args, input=json.dumps({'operation':'submit','payload':REQUEST}), text=True, capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr); self.assertTrue(json.loads(p.stdout)['ok'])
        p = subprocess.run(args, input='{bad', text=True, capture_output=True)
        self.assertEqual(p.returncode, 1); self.assertEqual(json.loads(p.stdout)['error'], 'invalid_command_or_configuration')


if __name__ == '__main__': unittest.main()
