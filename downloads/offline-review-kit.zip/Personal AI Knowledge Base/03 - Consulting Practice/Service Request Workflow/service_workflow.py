"""Local fictional service workflow. No network/provider is constructed here."""
import argparse
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sqlite3
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'Public Document Research'))
from public_research import answer, load_passages, load_register
sys.path.insert(0, str(HERE.parent / 'Evaluation Lab'))
from model_runner import Completion

QUEUES = {'research-desk', 'access-review'}
ID = re.compile(r'[A-Za-z0-9_-]{1,64}\Z')


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


@dataclass(frozen=True)
class Actor:
    id: str
    roles: frozenset


class WorkflowError(Exception):
    def __init__(self, code, status=400):
        self.code, self.status = code, status


def shape(data, required, optional=()):
    if not isinstance(data, dict) or set(data) - set(required) - set(optional) or set(required) - set(data):
        raise WorkflowError('invalid_fields')


def text(value, limit=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise WorkflowError('invalid_text')


def identifier(value):
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise WorkflowError('invalid_id')


class Workflow:
    def __init__(self, database, corpus=(), *, advisor=None, enable_ai=False, action=None):
        if enable_ai and advisor is None:
            raise ValueError('An explicitly injected advisor is required')
        self.advisor = advisor if enable_ai else None
        self.action = action
        # The local index is administrator-supplied; URLs alone cannot authenticate text.
        allowed = {s['id']: s['url'] for s in load_register(HERE.parent / 'Public Document Research/public_sources.json')}
        self.corpus = list(corpus)
        if any(not isinstance(r, dict) or not isinstance(r.get('source_id'), str)
               or r['source_id'] not in allowed or r.get('url') != allowed[r['source_id']]
               for r in self.corpus):
            raise ValueError('Unregistered reference source')
        self.db = sqlite3.connect(database, timeout=2)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS requests(
          id TEXT PRIMARY KEY, payload TEXT NOT NULL, recommendation TEXT NOT NULL,
          status TEXT NOT NULL, version INTEGER NOT NULL, queue TEXT, decision TEXT);
        CREATE TABLE IF NOT EXISTS decisions(
          id TEXT PRIMARY KEY, request_id TEXT REFERENCES requests(id), actor TEXT,
          payload TEXT, result TEXT);
        CREATE TABLE IF NOT EXISTS actions(
          request_id TEXT PRIMARY KEY REFERENCES requests(id), idempotency_key TEXT UNIQUE, receipt TEXT);
        CREATE TABLE IF NOT EXISTS audit(
          seq INTEGER PRIMARY KEY, at TEXT, request_id TEXT, actor TEXT, event TEXT, data TEXT);
        CREATE TABLE IF NOT EXISTS operations(
          seq INTEGER PRIMARY KEY, operation TEXT, actor TEXT, ok INTEGER, error TEXT, elapsed_s REAL);
        ''')

    def close(self):
        self.db.close()

    @contextmanager
    def transaction(self):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise

    def event(self, request_id, actor, event, data):
        self.db.execute('INSERT INTO audit(at,request_id,actor,event,data) VALUES(?,?,?,?,?)',
                        (datetime.now(timezone.utc).isoformat(), request_id, actor.id, event, encoded(data)))

    def require(self, actor, role):
        if role not in actor.roles:
            raise WorkflowError('permission_denied', 403)

    def row(self, request_id):
        identifier(request_id)
        row = self.db.execute('SELECT * FROM requests WHERE id=?', (request_id,)).fetchone()
        if row is None:
            raise WorkflowError('not_found', 404)
        result = dict(row)
        for name in ('payload', 'recommendation', 'decision'):
            result[name] = json.loads(result[name]) if result[name] else None
        return result

    def submit(self, data, actor):
        self.require(actor, 'submit')
        shape(data, ('request_id', 'kind', 'priority', 'description', 'reference_question'))
        identifier(data['request_id'])
        text(data['description']); text(data['reference_question'])
        if data['kind'] not in ('research', 'access', 'incident') or data['priority'] not in ('normal', 'urgent'):
            raise WorkflowError('invalid_category')
        payload = {**data, 'submitted_by': actor.id}
        with self.transaction():
            old = self.db.execute('SELECT payload FROM requests WHERE id=?', (data['request_id'],)).fetchone()
            if old:
                if old['payload'] != encoded(payload):
                    raise WorkflowError('id_conflict', 409)
                return self.row(data['request_id'])
            urgent = data['priority'] == 'urgent' or data['kind'] == 'incident'
            route = 'escalate' if urgent else {'research': 'research-desk', 'access': 'access-review'}[data['kind']]
            evidence = answer(data['reference_question'], self.corpus)
            recommendation = {'rule': 'fictional-routing-v1', 'queue': route, 'evidence': evidence,
                              'ai': {'enabled': self.advisor is not None, 'invocations': 0}}
            if self.advisor:
                ai = recommendation['ai']; ai['invocations'] = 1
                try:
                    completion = self.advisor(dict(data), deepcopy(evidence))  # Must return existing lab Completion.
                    if not isinstance(completion, Completion):
                        raise ValueError('Invalid completion')
                    for n in (completion.input_tokens, completion.output_tokens):
                        if n is not None and (type(n) is not int or n < 0):
                            raise ValueError('Invalid usage')
                    suggestion = json.loads(completion.text)
                    shape(suggestion, ('queue', 'reason')); text(suggestion['reason'], 500)
                    if suggestion['queue'] not in QUEUES | {'escalate'}:
                        raise ValueError('Invalid queue')
                    ai.update(suggestion=suggestion, model=completion.model,
                              input_tokens=completion.input_tokens, output_tokens=completion.output_tokens)
                except Exception:
                    # No raw provider exception/output is logged. Deterministic routing survives.
                    ai['error'] = 'advisor_failed'
            self.db.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?)',
                            (data['request_id'], encoded(payload), encoded(recommendation), 'awaiting_review', 0, None, None))
            self.event(data['request_id'], actor, 'recommendation_created', recommendation)
            return self.row(data['request_id'])

    def decide(self, data, actor):
        self.require(actor, 'review')
        shape(data, ('request_id', 'decision_id', 'expected_version', 'decision', 'reason'), ('queue',))
        identifier(data['decision_id']); text(data['reason'], 500)
        if type(data['expected_version']) is not int or data['expected_version'] < 0:
            raise WorkflowError('invalid_version')
        if data['decision'] not in ('approve', 'reject', 'escalate'):
            raise WorkflowError('invalid_decision')
        with self.transaction():
            row = self.row(data['request_id'])
            old = self.db.execute('SELECT * FROM decisions WHERE id=?', (data['decision_id'],)).fetchone()
            if old:
                if old['payload'] != encoded(data) or old['actor'] != actor.id:
                    raise WorkflowError('decision_id_conflict', 409)
                return json.loads(old['result'])
            if row['status'] != 'awaiting_review' or row['version'] != data['expected_version']:
                raise WorkflowError('stale_or_terminal_request', 409)
            queue = None
            if data['decision'] == 'approve':
                if actor.id == row['payload']['submitted_by']:
                    raise WorkflowError('self_approval_denied', 403)
                if row['recommendation']['queue'] == 'escalate':
                    raise WorkflowError('escalation_required', 409)
                if row['recommendation']['evidence']['status'] != 'extractive':
                    raise WorkflowError('missing_evidence', 409)
                queue = data.get('queue', row['recommendation']['queue'])
                if not isinstance(queue, str) or queue not in QUEUES:
                    raise WorkflowError('invalid_queue')
            elif 'queue' in data:
                raise WorkflowError('queue_only_on_approval')
            status = {'approve': 'approved', 'reject': 'rejected', 'escalate': 'escalated'}[data['decision']]
            decision = {**data, 'reviewed_by': actor.id, 'final_queue': queue}
            self.db.execute('UPDATE requests SET status=?,version=version+1,queue=?,decision=? WHERE id=?',
                            (status, queue, encoded(decision), row['id']))
            self.event(row['id'], actor, 'human_decision_recorded', decision)
            result = self.row(row['id'])
            self.db.execute('INSERT INTO decisions VALUES(?,?,?,?,?)',
                            (data['decision_id'], row['id'], actor.id, encoded(data), encoded(result)))
            return result

    def execute(self, data, actor):
        self.require(actor, 'execute'); shape(data, ('request_id',))
        try:
            with self.transaction():
                row = self.row(data['request_id'])
                if row['status'] == 'completed':
                    return json.loads(self.db.execute('SELECT receipt FROM actions WHERE request_id=?', (row['id'],)).fetchone()[0])
                if row['status'] not in ('approved', 'failed') or not row['decision'] or row['decision']['decision'] != 'approve':
                    raise WorkflowError('approval_required', 409)
                payload = {'operation': 'assign_queue', 'request_id': row['id'], 'queue': row['queue']}
                key = 'assign:' + row['id']
                receipt = self.action(key, dict(payload)) if self.action else {**payload, 'local_only': True, 'idempotency_key': key}
                if not isinstance(receipt, dict) or receipt.get('idempotency_key') != key or len(encoded(receipt)) > 8000:
                    raise ValueError('Invalid action receipt')
                self.db.execute('INSERT INTO actions VALUES(?,?,?)', (row['id'], key, encoded(receipt)))
                self.db.execute("UPDATE requests SET status='completed',version=version+1 WHERE id=?", (row['id'],))
                self.event(row['id'], actor, 'action_completed', {'payload': payload, 'receipt': receipt})
                return receipt
        except WorkflowError:
            raise
        except Exception as exc:
            # External adapters must deduplicate key: their side effects cannot share a SQLite transaction.
            try:
                with self.transaction():
                    row = self.row(data['request_id'])
                    if row['status'] in ('approved', 'failed'):
                        self.db.execute("UPDATE requests SET status='failed',version=version+1 WHERE id=?", (row['id'],))
                        self.event(row['id'], actor, 'action_failed', {'code': 'action_failed'})
            except (sqlite3.Error, WorkflowError):
                pass
            if isinstance(exc, sqlite3.Error):
                raise WorkflowError('storage_unavailable', 503) from None
            raise WorkflowError('action_failed', 503) from None

    def get(self, data, actor):
        shape(data, ('request_id',))
        row = self.row(data['request_id'])
        if actor.id != row['payload']['submitted_by'] and not actor.roles & {'review', 'execute'}:
            raise WorkflowError('permission_denied', 403)
        row['audit'] = [dict(r) for r in self.db.execute('SELECT * FROM audit WHERE request_id=? ORDER BY seq', (row['id'],))]
        for entry in row['audit']:
            entry['data'] = json.loads(entry['data'])
        return row

    def metrics(self, data, actor):
        self.require(actor, 'execute'); shape(data, ())
        rows = list(self.db.execute('SELECT * FROM operations'))
        ai = [json.loads(r[0])['ai'] for r in self.db.execute('SELECT recommendation FROM requests')]
        calls = sum(a['invocations'] for a in ai)
        return {'operations': len(rows), 'failures': sum(not r['ok'] for r in rows),
                'failures_by_code': {code: sum(r['error'] == code for r in rows) for code in {r['error'] for r in rows if r['error']}},
                'elapsed_s_total': sum(r['elapsed_s'] for r in rows),
                'elapsed_s_max': max((r['elapsed_s'] for r in rows), default=0),
                'advisor_invocations': calls, 'advisor_failures': sum('error' in a for a in ai),
                'reported_input_tokens': sum(a.get('input_tokens') or 0 for a in ai),
                'reported_output_tokens': sum(a.get('output_tokens') or 0 for a in ai),
                'unknown_usage_invocations': sum(a['invocations'] and (a.get('input_tokens') is None or a.get('output_tokens') is None) for a in ai),
                'api_cost_usd': None if calls else 0, 'local_host_cost_usd': None,
                'cost_note': 'No provider configured by default; injected-advisor price and host costs are unmeasured.'}

    def handle(self, operation, data, actor):
        """JSON-compatible integration boundary. Actor comes from trusted host, never request JSON."""
        started = time.perf_counter(); code = None
        try:
            identifier(actor.id)
            if operation not in ('submit', 'decide', 'execute', 'get', 'metrics'):
                raise WorkflowError('unknown_operation', 404)
            try:
                valid = isinstance(data, dict) and len(encoded(data)) <= 16000
            except (ValueError, TypeError, RecursionError):
                valid = False
            if not valid:
                raise WorkflowError('invalid_payload')
            result = getattr(self, operation)(data, actor)
            response = {'ok': True, 'status': 200, 'result': result}
        except WorkflowError as exc:
            code = exc.code; response = {'ok': False, 'status': exc.status, 'error': code, 'recoverable': exc.status in (409, 503)}
        except sqlite3.Error:
            code = 'storage_unavailable'; response = {'ok': False, 'status': 503, 'error': code, 'recoverable': True}
        except Exception:
            code = 'internal_error'; response = {'ok': False, 'status': 500, 'error': code, 'recoverable': False}
        try:
            with self.transaction():
                self.db.execute('INSERT INTO operations(operation,actor,ok,error,elapsed_s) VALUES(?,?,?,?,?)',
                                (operation, actor.id, int(response['ok']), code, time.perf_counter() - started))
            response['monitoring_persisted'] = True
        except sqlite3.Error:
            response['monitoring_persisted'] = False
        return response


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', required=True)
    parser.add_argument('--index', type=Path)
    parser.add_argument('--actor', choices=('requester', 'reviewer', 'operator'), required=True,
                        help='Trusted local DEMO identity selection; not authentication')
    args = parser.parse_args()
    actors = {'requester': Actor('demo-requester', frozenset({'submit'})),
              'reviewer': Actor('demo-reviewer', frozenset({'review'})),
              'operator': Actor('demo-operator', frozenset({'execute'}))}
    workflow = None
    try:
        raw = sys.stdin.read(18001)
        if len(raw) > 18000:
            raise ValueError('Input too large')
        command = json.loads(raw); shape(command, ('operation', 'payload'))
        workflow = Workflow(args.db, load_passages(args.index) if args.index else ())
        result = workflow.handle(command['operation'], command['payload'], actors[args.actor])
    except sqlite3.Error:
        result = {'ok': False, 'status': 503, 'error': 'storage_unavailable', 'recoverable': True}
    except (ValueError, OSError, TypeError, KeyError, AttributeError, RecursionError, WorkflowError):
        result = {'ok': False, 'status': 400, 'error': 'invalid_command_or_configuration'}
    finally:
        if workflow:
            workflow.close()
    print(encoded(result))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
