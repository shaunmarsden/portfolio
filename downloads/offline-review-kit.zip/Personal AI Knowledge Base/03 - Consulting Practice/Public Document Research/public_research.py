"""Public-document research CLI. Read-only by default; no model calls.

Python 3.9+ standard library. Treat retrieved pages as untrusted data.
No employer content, credentials, or source text is committed by the tool.
"""
import argparse
import hashlib
from html.parser import HTMLParser
import json
import math
import os
from pathlib import Path
import re
import sys
import urllib.request
from urllib.parse import urlparse
from collections import Counter
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
MAX_BYTES = 400000
MAX_SOURCE_BYTES = 1000000
STOP = set("a an and are as at be by can for from how in is it of on or the to what when where which who why with you your does do".split())


def tokens(value):
    return [w for w in re.findall(r"[a-z0-9]+", value.lower()) if w not in STOP and len(w) > 2]


class DocumentText(str):
    """Extracted text with local coverage metadata, still usable as a plain string."""

    def __new__(cls, value, *, blocks=None, dynamic_sections=None, download=None):
        obj = super().__new__(cls, value)
        obj.blocks = blocks
        obj.dynamic_sections = dynamic_sections or []
        obj.download = download or {}
        return obj


class PlainText(HTMLParser):
    """Keep source structure, without executing scripts or fetching dynamic fragments."""

    HIDDEN = {"script", "style", "nav", "footer", "head", "header", "aside", "button", "form", "svg"}
    BLOCKS = {"p", "li", "h1", "h2", "h3", "h4", "h5", "h6", "dt", "dd", "pre"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.hidden = 0
        self.blocks = []
        self.buffer = []
        self.kind = "paragraph"
        self.heading = ""
        self.main_depth = 0
        self.in_main = False
        self.dynamic_sections = []
        self.table = False
        self.headers = []
        self.cells = []
        self.cell = None
        self.header_row = False
        self.lists = []
        self.focus_tag = None
        self.focus_depth = 0
        self.focus_seen = False

    def flush(self):
        text = " ".join("".join(self.buffer).split())
        self.buffer = []
        if not text:
            return
        if self.kind == "heading":
            self.heading = text
            return
        self.blocks.append({"text": text, "heading": self.heading,
                            "kind": self.kind, "main": self.in_main, "content": bool(self.focus_depth)})

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in self.HIDDEN:
            if not self.hidden:
                self.flush()
            self.hidden += 1
        if self.hidden:
            return
        if attrs.get("id") == "mainContent":
            self.flush()
            self.focus_tag = tag
            self.focus_depth = 1
            self.focus_seen = True
            self.heading = ""
        elif tag == self.focus_tag and self.focus_depth:
            self.focus_depth += 1
        if tag == "main":
            self.flush()
            self.main_depth += 1
            self.in_main = True
        if attrs.get("hx-get"):
            self.dynamic_sections.append({"element_id": attrs.get("id"),
                                          "fragment_url": attrs["hx-get"],
                                          "trigger": attrs.get("hx-trigger")})
        if tag == "table":
            self.flush()
            self.table = True
            self.headers = []
        elif self.table and tag == "tr":
            self.cells = []
            self.header_row = False
        elif self.table and tag in {"td", "th"}:
            self.cell = []
            self.header_row = self.header_row or tag == "th"
        elif not self.table and tag in {"ul", "ol"}:
            self.flush()
            start = len(self.blocks)
            if (self.blocks and self.blocks[-1].get("content") == bool(self.focus_depth)
                    and self.blocks[-1]["main"] == self.in_main
                    and (self.blocks[-1]["text"].endswith(":") or
                         re.search(r"\b(following|steps|ingredients|factors)\b", self.blocks[-1]["text"], re.I))):
                start -= 1
            self.lists.append(start)
        elif not self.table and tag in self.BLOCKS:
            self.flush()
            is_heading = tag.startswith("h") and tag[1:].isdigit()
            is_heading = is_heading or tag == "dt" or "glossary-term__title" in attrs.get("class", "")
            self.kind = "heading" if is_heading else "paragraph"
        elif tag == "br":
            self.handle_data(" ")

    def handle_endtag(self, tag):
        if tag in self.HIDDEN:
            if self.hidden:
                self.hidden -= 1
            return
        if self.hidden:
            return
        if self.table and tag in {"td", "th"}:
            self.cells.append(" ".join("".join(self.cell or []).split()))
            self.cell = None
        elif self.table and tag == "tr":
            if self.header_row:
                self.headers = self.cells[:]
            elif any(self.cells):
                labels = self.headers if len(self.headers) == len(self.cells) else []
                text = " | ".join((labels[i] + ": " if labels else "") + value
                                  for i, value in enumerate(self.cells))
                self.blocks.append({"text": text, "heading": self.heading,
                                    "kind": "table_row", "main": self.in_main, "content": bool(self.focus_depth)})
        elif tag == "table":
            self.table = False
        elif tag in {"ul", "ol"} and self.lists:
            self.flush()
            start = self.lists.pop()
            group = self.blocks[start:]
            if group:
                self.blocks[start:] = [{"text": " ".join(b["text"] for b in group),
                                       "heading": group[0]["heading"], "kind": "list",
                                       "main": group[0]["main"], "content": group[0].get("content", False)}]
            self.kind = "paragraph"
        elif not self.table and tag in self.BLOCKS:
            self.flush()
            self.kind = "paragraph"
        if tag == "main":
            self.flush()
            self.main_depth = max(0, self.main_depth - 1)
            self.in_main = bool(self.main_depth)
        if tag == self.focus_tag and self.focus_depth:
            if self.focus_depth == 1:
                self.flush()
            self.focus_depth -= 1

    def handle_data(self, data):
        if not self.hidden:
            if self.cell is not None:
                self.cell.append(data)
            else:
                self.buffer.append(data)

    def text(self):
        self.flush()
        blocks = self.blocks
        if self.focus_seen:
            blocks = [b for b in blocks if b.get("content")]
        elif any(b["main"] for b in blocks):
            blocks = [b for b in blocks if b["main"]]
        # Preserve definition names in the quote, without discarding short labels.
        blocks = [{**b, "text": (b["heading"] + " — " + b["text"]
                                if b["heading"] and b["heading"] not in b["text"]
                                and b["kind"] == "paragraph" else b["text"])} for b in blocks]
        return DocumentText("\n".join(b["text"] for b in blocks), blocks=blocks,
                            dynamic_sections=self.dynamic_sections)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def validate_sources(rows):
    if not isinstance(rows, list) or not rows:
        raise ValueError("Source register must be a nonempty list")
    found = set()
    for source in rows:
        if not isinstance(source, dict) or not all(source.get(k) for k in ("id", "title", "url", "publisher")):
            raise ValueError("Each source needs id, title, url and publisher")
        limit = source.get("max_bytes", MAX_BYTES)
        if type(limit) is not int or not 1 <= limit <= MAX_SOURCE_BYTES:
            raise ValueError("Source max_bytes must be an integer within the hard 1000000-byte ceiling")
        if source["id"] in found:
            raise ValueError("Duplicate source ID")
        found.add(source["id"])
        uri = urlparse(source["url"])
        if uri.scheme != "https" or not uri.hostname or uri.username or uri.password or uri.port:
            raise ValueError("Only public HTTPS source URLs are supported")
        if uri.hostname not in ("www.nist.gov", "skillsengland.education.gov.uk", "developers.openai.com"):
            raise ValueError("URL host is not in the audited public-source allowlist")
    return rows


def load_register(path):
    return validate_sources(json.loads(Path(path).read_text(encoding="utf-8")))


def fetch_public(source, opener=None):
    """Explicit network operation, never during search, answer or evaluation."""
    opener = opener or urllib.request.build_opener(NoRedirect()).open
    limit = source.get("max_bytes", MAX_BYTES)
    if type(limit) is not int or not 1 <= limit <= MAX_SOURCE_BYTES:
        raise ValueError("Invalid source byte limit")
    request = urllib.request.Request(source["url"], headers={"User-Agent": "PersonalPublicResearch/0.1"})
    with opener(request, timeout=15) as response:
        content_type = response.headers.get("Content-Type", "").lower()
        if "text/html" not in content_type and "text/plain" not in content_type:
            raise ValueError("Unsupported content type")
        raw = response.read(limit + 1)
        download = {"http_status": getattr(response, "status", None), "content_type": content_type,
                    "bytes_read": len(raw), "max_bytes": limit,
                    "raw_sha256": hashlib.sha256(raw).hexdigest()}
    if len(raw) > limit:
        raise ValueError("Source exceeds size limit (" + str(limit) + " bytes)")
    text = raw.decode("utf-8", errors="replace")
    if "html" in content_type:
        parser = PlainText()
        parser.feed(text)
        parser.close()
        text = parser.text()
    if not isinstance(text, DocumentText):
        text = DocumentText(text)
    text.download = download
    return text


def passages(text, source):
    """Keep normalized source blocks with heading/table context; never invent content."""
    output = []
    blocks = getattr(text, "blocks", None)
    if blocks is None:
        blocks = [{"text": para, "heading": "", "kind": "paragraph"} for para in text.splitlines()]
    grouped = []
    for block in blocks:
        if (grouped and grouped[-1].get("kind") == "list" and block.get("kind") == "paragraph"
                and grouped[-1].get("heading") == block.get("heading")
                and len(grouped[-1]["text"]) + len(block["text"]) < 1600):
            grouped[-1] = {**grouped[-1], "text": grouped[-1]["text"] + " " + block["text"]}
        else:
            grouped.append(dict(block))
    seen = set()
    for block in grouped:
        para = " ".join(block["text"].split())
        if not para or not tokens(para):
            continue
        if re.search(r"\bThis link will take you\b", para):
            continue  # Site link-helper text is navigation, not an informational answer.
        # Bound individual passages without silently dropping an overlong block.
        pieces = []
        while len(para) > 1600:
            boundary = para.rfind(" ", 0, 1601)
            boundary = boundary if boundary > 0 else 1600
            pieces.append(para[:boundary])
            para = para[boundary:].lstrip()
        pieces.append(para)
        for piece in pieces:
            if (len(piece) < 20 and len(pieces) == 1) or piece in seen:
                continue
            seen.add(piece)
            output.append({"id": source["id"] + ":P" + str(len(output) + 1),
                           "source_id": source["id"], "text": piece,
                           "url": source["url"], "title": source["title"],
                           "heading": block.get("heading", ""), "kind": block.get("kind", "paragraph")})
    return output


def ingest(register, out_dir, fetch=fetch_public, allow_partial=False):
    """Persist per-source outcomes, even on failure; partial ingestion requires opt-in."""
    validate_sources(register)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    index = []
    manifest = []
    for source in register:
        record = {"source_id": source["id"], "url": source["url"], "publisher": source["publisher"],
                  "max_bytes": source.get("max_bytes", MAX_BYTES)}
        try:
            text = fetch(source)
            page = passages(text, source)
            if not page:
                raise ValueError("No usable passages")
            dynamic = getattr(text, "dynamic_sections", [])
            record.update(status="incomplete_dynamic" if dynamic else "extracted",
                          complete=not dynamic, dynamic_sections=dynamic,
                          extracted_text_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
                          passage_count=len(page), download=getattr(text, "download", {}))
            for row in page:
                row["source_complete"] = not dynamic
            index.extend(page)
        except (ValueError, OSError, UnicodeError) as exc:
            record.update(status="failed", complete=False, passage_count=0,
                          error_type=type(exc).__name__, error=str(exc),
                          http_status=getattr(exc, "code", None))
        manifest.append(record)
    complete = all(r["complete"] for r in manifest)
    (out_dir / "passages.json").write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_dir / "manifest.json").write_text(json.dumps({
        "created_utc": datetime.now(timezone.utc).isoformat(), "extraction_version": 2, "complete": complete,
        "sources": manifest, "note": "Extraction status is not editorial verification or proof of answer support."
    }, indent=2), encoding="utf-8")
    if not complete and not allow_partial:
        raise ValueError("Ingestion incomplete; inspect manifest.json. Partial index saved; use --allow-partial explicitly to accept it.")
    return index


# Keep the original tokenizer/baseline unchanged for a fair historical comparison.
QUERY_FILLER = set("was were been being did its their our this that these those it they should could would please page document guide mean means part use main".split())
WORD_FORMS = {"publications": "publish", "publication": "publish", "published": "publish",
              "accompany": "companion", "accompanies": "companion",
              "evaluation": "eval", "evaluations": "eval", "workflow": "process"}


def research_terms(value):
    """Small lexical normalization, not semantic search or an entailment model."""
    result = []
    for word in re.findall(r"[a-z][a-z0-9]*|[0-9]+(?:[./-][0-9]+)*", value.lower()):
        if word in STOP or word in QUERY_FILLER or word == "ai":
            continue
        word = WORD_FORMS.get(word, word)
        if len(word) > 5 and word.endswith("ies"):
            word = word[:-3] + "y"
        elif len(word) > 4 and word.endswith("s") and not word.endswith("ss"):
            word = word[:-1]
        if len(word) > 5 and word.endswith("ing"):
            word = word[:-3]
        elif len(word) > 4 and word.endswith("ed"):
            word = word[:-2]
        if len(word) > 4 and word.endswith("e"):
            word = word[:-1]
        if len(word) > 2 or word[0].isdigit():
            result.append(word)
    return result


def evidence_text(row):
    return row.get("heading", "") + " " + row["text"]


def source_scope(question, corpus):
    """An explicit registered identifier must not be answered from another source."""
    words = set(re.findall(r"[a-z0-9]+", question.lower()))
    scoped = set()
    for row in corpus:
        aliases = set(re.findall(r"[a-z0-9]+", row["source_id"].lower()))
        if any(len(a) > 2 and a in words for a in aliases):
            scoped.add(row["source_id"])
    return scoped


def coverage(question, row):
    q = set(research_terms(question))
    doc = set(research_terms(evidence_text(row)))
    # Source names and a document's URL/title identify scope; they do not count
    # as evidence for a requested fee, guarantee, date or other missing claim.
    context = set(research_terms(row["source_id"] + " " + row["title"] + " " + row["url"]))
    core = q - context
    if not core:
        return 0.0
    return len(core & doc) / len(core)


def rank(question, corpus):
    q = Counter(research_terms(question))
    docs = [Counter(research_terms(evidence_text(row))) for row in corpus]
    df = Counter(t for doc in docs for t in doc)
    n = len(corpus)
    scope = source_scope(question, corpus)
    results = []
    for row, doc in zip(corpus, docs):
        if not q or not doc or (scope and row["source_id"] not in scope):
            continue
        if re.search(r"\bThis link will take you\b", row["text"]):
            continue
        score = sum(min(q[t], doc[t]) * math.log(1 + (n + 1) / (df[t] + 1))
                    for t in q if t in doc)
        score = score / math.sqrt(len(doc)) * coverage(question, row) ** 2
        if score > 0:
            results.append((score, row))
    return sorted(results, key=lambda x: (-x[0], x[1]["id"]))


def baseline(question, corpus):
    """Deliberately simple comparison: first passage containing all meaningful query terms."""
    q = set(tokens(question))
    for row in corpus:
        if q and q.issubset(set(tokens(row["text"]))):
            return row["source_id"]
    return None


def answer(question, corpus, minimum=0.35):
    if not isinstance(question, str) or not question.strip() or len(question) > 2000:
        raise ValueError("Question must be nonempty, at most 2000 characters")
    def abstain(reason):
        return {"status": "abstain", "answer": None, "citations": [], "reason": reason}
    scope = source_scope(question, corpus)
    # A matching example is not evidence of the user's intended task or entity.
    # Definitions ask about a field's meaning; label values need an actual input.
    lower = question.lower()
    definition = re.search(r"^\s*what\s+(?:does|do)\b.+\b(?:mean|represent|refer|contain)\b|\b(?:meaning|definition)\s+of\b", lower)
    if re.search(r"\b(?:correct[ _-])?labels?\b", lower) and not definition:
        task = re.search(r"\b(?:it|support)\s+(?:support\s+)?tickets?\b", lower)
        sample = re.search(r'["“][^"”]{3,}["”]|\b(?:ticket|input)\s*:\s*\S.{2,}', question, re.IGNORECASE)
        if not (task and (sample or re.search(r"\blabels\b", lower))):
            return abstain("Specify the classification task and input before requesting a label")
    if re.search(r"\bversions?\b", lower) and not scope and not definition:
        # Preserve the existing numbered assessment-plan revision query, while
        # approval wording or a bare version number cannot identify the entity.
        component = re.search(r"\b(?:assessment plan|occupational standard)\b", lower)
        numbered = re.search(r"\bversions?\s+\d+(?:\.\d+)+\b", lower)
        if not (component and numbered):
            return abstain("Specify the registered source or entity whose version is requested")
    meaningful = set(research_terms(question))
    if len(scope) > 1:
        return abstain("Question requests multiple sources; one passage cannot establish the comparison")
    generic = {"framework", "assessment", "releas", "date", "apply", "standard", "policy"}
    if not scope and (len(meaningful) < 2 or not meaningful - generic):
        return abstain("Insufficient context; clarify the entity or type of information requested")
    candidates = rank(question, corpus)
    if not candidates:
        return abstain("No sufficiently relevant passage")
    score, best = candidates[0]
    requested_numbers = {t for t in research_terms(question) if t[0].isdigit()}
    evidence_numbers = {t for t in research_terms(evidence_text(best)) if t[0].isdigit()}
    if not requested_numbers.issubset(evidence_numbers):
        return abstain("Requested numeric/version constraints are absent from the passage")
    if best["text"].rstrip().endswith(":"):
        return abstain("Retrieved introduction is missing its supporting list")
    if score < minimum or coverage(question, best) < 0.7:
        return abstain("Insufficient coverage of the question in the cited evidence")
    if re.search(r"^\s*when\b|\b(?:start|release|revision|publication) date\b|\bwhat date\b", question.lower()) and not re.search(
            r"\d{4}|\d{1,2}[/.-]\d{1,2}", best["text"]):
        return abstain("The retrieved passage does not provide a date")
    return {"status": "extractive", "answer": best["text"],
            "citations": [{"passage_id": best["id"], "source_id": best["source_id"],
                           "url": best["url"], "quote": best["text"],
                           "heading": best.get("heading", ""),
                           "quote_format": "normalized_source_block",
                           "source_complete": best.get("source_complete")}],
            "score": round(score, 5),
            "question_coverage": round(coverage(question, best), 3),
            "warning": "Lexical evidence checks, not proof of entailment; source completeness is separate"}


def evaluate(corpus, questions):
    """Offline labels identify a supporting source or explicitly expected abstention."""
    results = []
    for item in questions:
        response = answer(item["question"], corpus)
        predicted = response["citations"][0]["source_id"] if response["citations"] else None
        ref = item["expected_source_id"]
        original = baseline(item["question"], corpus)
        results.append({"id": item["id"], "expected_source_id": ref,
                        "retrieval_source_id": predicted, "baseline_source_id": original,
                        "retrieval_correct": predicted == ref, "baseline_correct": original == ref,
                        "abstained": response["status"] == "abstain"})
    return {"cases": len(results), "retrieval_correct": sum(r["retrieval_correct"] for r in results),
            "baseline_correct": sum(r["baseline_correct"] for r in results),
            "results": results,
            "limitation": "Manually-labelled small offline cases; source selection does not establish claim truth or answer sufficiency"}


def load_passages(path):
    rows = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(rows, list) or any(not all(isinstance(r.get(k), str) and r[k] for k in
              ("id", "source_id", "url", "title", "text")) for r in rows):
        raise ValueError("Invalid passage index")
    return rows


def main(argv=None):
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("ingest")
    p.add_argument("--sources", default=str(HERE / "public_sources.json"))
    p.add_argument("--out", required=True)
    p.add_argument("--allow-partial", action="store_true", help="explicitly accept an incomplete index; manifest still records failures")
    p = sub.add_parser("ask")
    p.add_argument("--index", required=True)
    p.add_argument("--question", required=True)
    p = sub.add_parser("evaluate")
    p.add_argument("--index", required=True)
    p.add_argument("--cases", required=True)
    args = parser.parse_args(argv)
    try:
        if args.cmd == "ingest":
            rows = ingest(load_register(args.sources), args.out, allow_partial=args.allow_partial)
            manifest = json.loads((Path(args.out) / "manifest.json").read_text(encoding="utf-8"))
            result = {"passages": len(rows), "complete": manifest["complete"],
                      "incomplete_sources": [s["source_id"] for s in manifest["sources"] if not s["complete"]]}
        elif args.cmd == "ask":
            result = answer(args.question, load_passages(args.index))
        else:
            result = evaluate(load_passages(args.index), json.loads(Path(args.cases).read_text(encoding="utf-8")))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError) as exc:
        print("Error: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
