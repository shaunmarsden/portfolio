#!/usr/bin/env python3
"""Offline routing evaluation. Synthetic dataset; no network, models or real service advice."""
import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

SOURCES = {"permit": "S-PERMIT", "parking": "S-PARK", "housing": "S-HOUSE"}
ROUTES = set(SOURCES) | {"other", "escalate"}
FIELDS = {"id", "route", "source_ids", "answer", "escalate"}


def read_jsonl(path):
    result = []
    with open(path, encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            if line.strip():
                try:
                    result.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Line {number}: invalid JSON ({exc.msg})") from exc
    return result


def read_cases(path):
    rows = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(rows, list) or not rows:
        raise ValueError("Reference corpus must be a non-empty list")
    ids = [row["id"] for row in rows]
    if len(ids) != len(set(ids)) or any(row["route"] not in ROUTES for row in rows):
        raise ValueError("Duplicate reference IDs or invalid reference routes")
    return rows


def safe_response(case, route):
    return {"id": case["id"], "route": route,
            "source_ids": [SOURCES[route]] if route in SOURCES else [],
            "answer": "Please contact a human adviser." if route == "escalate" else "Please use the relevant information service.",
            "escalate": route == "escalate"}


def keyword_route(query):
    q = query.lower()
    if re.search(r"cancel|waive|guarantee|promise|emergency|urgent|immediate danger|legally|legal meaning|approve|eligibility decision", q):
        return "escalate"
    if "parking" in q:
        return "parking"
    if "housing" in q:
        return "housing"
    if "permit" in q:
        return "permit"
    return "other"


def generate(cases, method):
    if method == "baseline":
        return [safe_response(c, keyword_route(c["query"])) for c in cases]
    if method == "perfect":
        return [safe_response(c, c["route"]) for c in cases]
    if method == "faulty_mock":
        out = [safe_response(c, c["route"]) for c in cases]
        for row in out:
            if row["id"] == "T08":
                row.update(route="other", source_ids=[])
            if row["id"] == "T23":
                row.update(route="housing", source_ids=["S-HOUSE"], escalate=False)
            if row["id"] == "T27":
                row.update(route="permit", source_ids=["S-FAKE"], escalate=False)
        return out
    raise ValueError(f"Unknown method: {method}")


def score(cases, responses):
    references = {case["id"]: case for case in cases}
    received, issues = {}, []
    for index, obj in enumerate(responses, 1):
        if not isinstance(obj, dict) or not isinstance(obj.get("id"), str):
            issues.append({"line": index, "kind": "malformed_id"})
            continue
        rid = obj["id"]
        if rid not in references:
            issues.append({"id": rid, "kind": "unknown_id"})
        elif rid in received:
            issues.append({"id": rid, "kind": "duplicate_id"})
        else:
            received[rid] = obj
    route_ok = 0
    valid_schema = 0
    critical_misses = 0
    false_escalations = 0
    variant_stats = defaultdict(lambda: [0, 0])
    group_predictions = defaultdict(list)
    confusion = Counter()
    for case in cases:
        rid = case["id"]
        row = received.get(rid)
        if row is None:
            issues.append({"id": rid, "kind": "missing_response"})
            if case["route"] == "escalate":
                critical_misses += 1
            continue
        route, cites, answer, flag = (row.get(k) for k in ("route", "source_ids", "answer", "escalate"))
        valid = (set(row) == FIELDS and isinstance(route, str) and route in ROUTES
                 and isinstance(cites, list) and all(isinstance(s, str) for s in cites)
                 and isinstance(answer, str) and bool(answer.strip()) and isinstance(flag, bool))
        if not valid:
            issues.append({"id": rid, "kind": "invalid_schema"})
        else:
            valid_schema += 1
        source_expected = [SOURCES[route]] if isinstance(route, str) and route in SOURCES else []
        if isinstance(cites, list) and cites != source_expected or not isinstance(cites, list):
            issues.append({"id": rid, "kind": "source_mismatch"})
        if isinstance(flag, bool) and flag != (route == "escalate") or not isinstance(flag, bool):
            issues.append({"id": rid, "kind": "flag_mismatch"})
        correct = bool(valid and route == case["route"] and cites == source_expected and flag == (route == "escalate"))
        route_ok += int(correct)
        variant_stats[case["variant"]][1] += 1
        variant_stats[case["variant"]][0] += int(correct)
        if isinstance(route, str) and route in ROUTES:
            group_predictions[case["group"]].append(route)
        confusion[f"{case['route']} -> {route!r}"] += 1
        if not correct:
            issues.append({"id": rid, "kind": "incorrect_case", "expected": case["route"], "actual": route})
        if case["route"] == "escalate" and not (correct and route == "escalate"):
            critical_misses += 1
        if case["route"] != "escalate" and route == "escalate":
            false_escalations += 1
    eligible_groups = {g: predictions for g, predictions in group_predictions.items() if len(predictions) > 1}
    inconsistent_groups = sorted(g for g, predictions in eligible_groups.items() if len(set(predictions)) > 1)
    n = len(cases)
    return {"dataset": "fictional_service_router_v2", "kind": "synthetic_offline_evaluation",
            "total": n, "received_unique": len(received), "schema_valid": valid_schema,
            "fully_correct": route_ok, "accuracy": round(route_ok / n, 4),
            "critical_cases": sum(c["route"] == "escalate" for c in cases),
            "critical_misses": critical_misses, "false_escalations": false_escalations,
            "inconsistent_paraphrase_groups": inconsistent_groups,
            "variant_scores": {k: {"correct": v[0], "total": v[1]} for k, v in sorted(variant_stats.items())},
            "confusion": dict(sorted(confusion.items())), "issues": issues,
            "limitations": "No semantic validation of answers, no representative sample, and no AI model call."}


def self_test(cases):
    perfect = score(cases, generate(cases, "perfect"))
    assert perfect["fully_correct"] == len(cases) and not perfect["issues"]
    mock = score(cases, generate(cases, "faulty_mock"))
    assert mock["critical_misses"] == 2 and mock["fully_correct"] == len(cases) - 3
    assert any(i["kind"] == "source_mismatch" for i in mock["issues"])
    duplicate = score(cases, [generate(cases, "perfect")[0]] * 2)
    assert any(i["kind"] == "duplicate_id" for i in duplicate["issues"])
    missing = score(cases, [])
    assert missing["critical_misses"] == 12
    malformed = generate(cases, "perfect")
    malformed[0]["route"] = ["permit"]
    assert any(i["kind"] == "invalid_schema" for i in score(cases, malformed)["issues"])
    blank = generate(cases, "perfect")
    blank[0]["answer"] = "   "
    assert any(i["kind"] == "invalid_schema" for i in score(cases, blank)["issues"])
    altered = generate(cases, "perfect")
    altered[0]["escalate"] = True
    assert any(i["kind"] == "flag_mismatch" for i in score(cases, altered)["issues"])
    fabricated = generate(cases, "perfect")
    fabricated[0]["source_ids"] = ["S-FAKE"]
    assert any(i["kind"] == "source_mismatch" for i in score(cases, fabricated)["issues"])
    print("Self-test PASS: controls, critical misses, duplicate, missing, malformed, blank, flag and citation checks")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, default=Path(__file__).with_name("cases_v2.json"))
    choices = parser.add_mutually_exclusive_group(required=True)
    choices.add_argument("--baseline", action="store_true")
    choices.add_argument("--faulty-mock", action="store_true")
    choices.add_argument("--perfect", action="store_true")
    choices.add_argument("--responses", type=Path)
    choices.add_argument("--export-queries", type=Path)
    choices.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    try:
        cases = read_cases(args.cases)
        if args.self_test:
            self_test(cases)
            return
        if args.export_queries:
            with args.export_queries.open("w", encoding="utf-8") as out:
                for c in cases:
                    out.write(json.dumps({"id": c["id"], "query": c["query"]}, ensure_ascii=False) + "\n")
            print(f"Exported {len(cases)} synthetic queries")
            return
        if args.responses:
            rows = read_jsonl(args.responses)
        else:
            method = "baseline" if args.baseline else ("faulty_mock" if args.faulty_mock else "perfect")
            rows = generate(cases, method)
        result = score(cases, rows)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["issues"]:
        sys.exit(1)

if __name__ == "__main__":
    main()
