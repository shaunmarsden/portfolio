"""Unit and regression tests for the synthetic evaluation engine."""
import copy
import tempfile
import unittest
from pathlib import Path
import evaluate_v2 as lab


class EvaluationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = lab.read_cases(Path(__file__).with_name('cases_v2.json'))

    def test_reference_distribution(self):
        self.assertEqual(len(self.cases), 32)
        self.assertEqual(sum(x['route'] == 'escalate' for x in self.cases), 12)
        self.assertEqual(len(set(x['id'] for x in self.cases)), 32)

    def test_perfect_control(self):
        result = lab.score(self.cases, lab.generate(self.cases, 'perfect'))
        self.assertEqual(result['fully_correct'], 32)
        self.assertEqual(result['critical_misses'], 0)
        self.assertEqual(result['issues'], [])

    def test_faulty_mock(self):
        result = lab.score(self.cases, lab.generate(self.cases, 'faulty_mock'))
        self.assertEqual(result['fully_correct'], 29)
        self.assertEqual(result['critical_misses'], 2)
        self.assertIn('escalate_b', result['inconsistent_paraphrase_groups'])
        self.assertTrue(any(i['kind'] == 'source_mismatch' for i in result['issues']))

    def test_keyword_baseline(self):
        result = lab.score(self.cases, lab.generate(self.cases, 'baseline'))
        self.assertEqual(result['fully_correct'], 26)
        self.assertEqual(result['critical_misses'], 0)
        self.assertEqual(len(result['inconsistent_paraphrase_groups']), 3)

    def test_missing_and_duplicate(self):
        responses = lab.generate(self.cases, 'perfect')
        responses.pop(0)
        responses.append(copy.deepcopy(responses[0]))
        result = lab.score(self.cases, responses)
        kinds = {x['kind'] for x in result['issues']}
        self.assertIn('missing_response', kinds)
        self.assertIn('duplicate_id', kinds)

    def test_critical_case_missing(self):
        responses = lab.generate(self.cases, 'perfect')[:-1]
        result = lab.score(self.cases, responses)
        self.assertEqual(result['critical_misses'], 1)

    def test_malformed_route(self):
        responses = lab.generate(self.cases, 'perfect')
        responses[0]['route'] = ['permit']
        result = lab.score(self.cases, responses)
        self.assertTrue(any(x['kind'] == 'invalid_schema' for x in result['issues']))

    def test_blank_or_extra_field(self):
        responses = lab.generate(self.cases, 'perfect')
        responses[0]['answer'] = ' '
        responses[1]['extra'] = 123
        result = lab.score(self.cases, responses)
        self.assertEqual(sum(x['kind'] == 'invalid_schema' for x in result['issues']), 2)

    def test_source_and_flag_inconsistency(self):
        responses = lab.generate(self.cases, 'perfect')
        responses[0]['source_ids'] = ['S-NOT-IN-REGISTER']
        responses[1]['escalate'] = True
        result = lab.score(self.cases, responses)
        self.assertTrue(any(x['kind'] == 'source_mismatch' for x in result['issues']))
        self.assertTrue(any(x['kind'] == 'flag_mismatch' for x in result['issues']))

    def test_unknown_id(self):
        responses = lab.generate(self.cases, 'perfect')
        responses.append({'id': 'T99'})
        result = lab.score(self.cases, responses)
        self.assertTrue(any(x['kind'] == 'unknown_id' for x in result['issues']))

    def test_invalid_jsonl(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'broken.jsonl'
            p.write_text('{not json}\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                lab.read_jsonl(p)

    def test_out_of_scope_no_source(self):
        responses = lab.generate(self.cases, 'perfect')
        other = next(r for r in responses if r['id'] == 'T16')
        other['source_ids'] = ['S-PARK']
        result = lab.score(self.cases, responses)
        self.assertTrue(any(x['kind'] == 'source_mismatch' for x in result['issues']))


if __name__ == '__main__':
    unittest.main()
